console.log("✅ [Background] Ozon ERP Background 已启动");

const API_URL = "https://ozon.chaowei.online";
const API_KEY = "zhang147..";

// ===== 统一请求函数（自动带 token）=====
async function requestApi(path, options) {
  options = options || {};
  try {
    const url = API_URL + path;
    console.log("🌐 [Background] 请求:", url);

    const stored = await chrome.storage.local.get("erp_token");
    const userToken = stored.erp_token || null;

    const controller = new AbortController();
    const fetchTimer = setTimeout(() => controller.abort(), 120000);

    let res;
    try {
      res = await fetch(url, {
        method: options.method || "GET",
        headers: {
          "Content-Type": "application/json",
          "X-API-Key": API_KEY,
          ...(userToken ? { "Authorization": "Bearer " + userToken } : {})
        },
        body: options.body || undefined,
        signal: controller.signal
      });
    } finally {
      clearTimeout(fetchTimer);
    }

    const text = await res.text();
    console.log("📥 [Background] 状态:", res.status, path);

    let data = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch (e) {
      return {
        success: false,
        status: res.status,
        error: "JSON 解析失败：" + e.message
      };
    }

    if (!res.ok) {
      return {
        success: false,
        status: res.status,
        error: data?.msg || ("HTTP " + res.status),
        data: data
      };
    }

    return { success: true, status: res.status, data: data };
  } catch (e) {
    if (e.name === "AbortError") {
      return { success: false, error: "请求超时（120秒）" };
    }
    return { success: false, error: e.message };
  }
}

// ===== Seller Portal 通讯（只用于获取图片）=====
async function ensureSellerTab(timeoutMs = 20000) {
  const queryTabs = () => chrome.tabs.query({ url: "https://seller.ozon.ru/*" });
  const pickReadyTab = (list) =>
    list.find(t => t.status === "complete" && t.url?.includes("/app/"))
    || list.find(t => t.status === "complete")
    || null;

  let tabs = await queryTabs();
  let ready = pickReadyTab(tabs);
  if (ready) return ready;

  if (tabs.length) {
    const waitDeadline = Date.now() + timeoutMs;
    while (Date.now() < waitDeadline) {
      await new Promise(r => setTimeout(r, 500));
      tabs = await queryTabs();
      ready = pickReadyTab(tabs);
      if (ready) return ready;
      if (tabs.length === 0) break;
    }
  }

  console.log("[ensureSellerTab] 后台打开 seller.ozon.ru...");
  const created = await chrome.tabs.create({
    url: "https://seller.ozon.ru/app/products/copy/list",
    active: false,
    pinned: true
  });

  const createDeadline = Date.now() + timeoutMs;
  while (Date.now() < createDeadline) {
    await new Promise(r => setTimeout(r, 500));
    try {
      const t = await chrome.tabs.get(created.id);
      if (t.status === "complete") return t;
    } catch {
      throw new Error("seller.ozon.ru tab 已被关闭");
    }
  }
  throw new Error("seller.ozon.ru tab 加载超时");
}

async function fetchSellerPortal(path, body, timeoutMsOrOpts = 30000) {
  const opts = typeof timeoutMsOrOpts === "number"
    ? { timeoutMs: timeoutMsOrOpts }
    : (timeoutMsOrOpts || {});
  const timeoutMs = opts.timeoutMs || 30000;
  const urlPrefix = opts.urlPrefix !== undefined ? opts.urlPrefix : "/api/v1";
  const pageType = opts.pageType || "products";

  const targetTab = await ensureSellerTab();

  const scCookies = await chrome.cookies.getAll({
    url: "https://seller.ozon.ru/",
    name: "sc_company_id"
  });
  const companyId = scCookies[0]?.value || "";
  if (!companyId) {
    throw new Error("sc_company_id 未找到，请先登录 seller.ozon.ru");
  }

  const doFetch = async (apiPath, reqBody, xCompanyId, timeout, prefix, pageTypeHdr) => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const resp = await fetch("https://seller.ozon.ru" + (prefix || "/api/v1") + apiPath, {
        method: "POST",
        signal: controller.signal,
        credentials: "include",
        headers: {
          "accept": "application/json, text/plain, */*",
          "content-type": "application/json",
          "x-o3-app-name": "seller-ui",
          "x-o3-company-id": xCompanyId,
          "x-o3-language": "zh-Hans",
          "x-o3-page-type": pageTypeHdr || "products"
        },
        body: JSON.stringify(reqBody)
      });
      clearTimeout(timer);
      if (resp.redirected && (resp.url.includes("/signin") || resp.url.includes("/login"))) {
        return { ok: false, status: 401, error: "Cookie 已过期，请重新登录 seller.ozon.ru" };
      }
      const text = await resp.text();
      if (!resp.ok) {
        return { ok: false, status: resp.status, error: `请求失败 (${resp.status}): ${text.slice(0, 200)}` };
      }
      let data;
      try {
        data = text ? JSON.parse(text) : {};
      } catch (e) {
        return { ok: false, error: "JSON解析失败" };
      }
      return { ok: true, data };
    } catch (e) {
      clearTimeout(timer);
      if (e.name === "AbortError") return { ok: false, error: `超时 (${timeout}ms)` };
      return { ok: false, error: e.message || String(e) };
    }
  };

  const results = await Promise.race([
    chrome.scripting.executeScript({
      target: { tabId: targetTab.id },
      func: doFetch,
      args: [path, body, companyId, timeoutMs, urlPrefix, pageType],
      world: "MAIN"
    }),
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error("executeScript 超时")), timeoutMs + 5000)
    )
  ]);

  const r = results?.[0]?.result;
  if (!r) throw new Error("executeScript 未返回结果");
  if (!r.ok) throw new Error(r.error || "unknown");
  return r.data;
}

// ===== 获取竞品图片 =====
async function getProductImages(sku) {
  try {
    const scCookies = await chrome.cookies.getAll({
      url: "https://seller.ozon.ru/",
      name: "sc_company_id"
    });
    const companyId = scCookies[0]?.value;
    if (!companyId) {
      console.warn("[图片] 未登录 seller.ozon.ru，跳过图片获取");
      return [];
    }

    const searchResp = await fetchSellerPortal(
      "/search",
      {
        company_id: companyId,
        filter: {
          children_nodes: {
            children_nodes: [
              { input_leaf: { sku: { values: [String(sku)] } } }
            ],
            operator: "AND"
          }
        },
        pagination: { limit: "1" }
      },
      { urlPrefix: "/api/v1", pageType: "products", timeoutMs: 30000 }
    );

    const variant = searchResp?.variants?.[0];
    if (!variant) {
      console.warn("[图片] 没找到竞品");
      return [];
    }

    const images = [];
    if (variant.main_image) images.push(variant.main_image);
    if (Array.isArray(variant.secondary_images)) {
      variant.secondary_images.forEach(img => {
        if (img && !images.includes(img)) images.push(img);
      });
    }

    console.log("[图片] 获取到图片:", images.length, "张");
    return images;

  } catch (e) {
    console.warn("[图片] 获取图片失败:", e.message);
    return [];
  }
}

// ===== 查询单个商品 =====
async function querySingle(id) {
  const stored = await chrome.storage.local.get("erp_token");
  if (stored.erp_token) {
    console.log("[querySingle] 走 /erp/query/" + id);
    return await requestApi("/erp/query/" + id);
  }
  console.log("[querySingle] 降级走 /full/" + id);
  return await requestApi("/full/" + id);
}

// ===== 批量查询 =====
async function queryItems(ids) {
  const uniqueIds = [...new Set((ids || []).map(i => String(i).trim()).filter(Boolean))];
  if (!uniqueIds.length) return { success: false, error: "ids 为空" };

  const stored = await chrome.storage.local.get("erp_token");
  if (stored.erp_token) {
    console.log("[queryItems] 走 /erp/full/batch，数量:", uniqueIds.length);
    return await requestApi("/erp/full/batch", {
      method: "POST",
      body: JSON.stringify({ ids: uniqueIds })
    });
  }
  console.log("[queryItems] 降级走 /full/batch");
  return await requestApi("/full/batch", {
    method: "POST",
    body: JSON.stringify({ ids: uniqueIds })
  });
}

// ===== 获取仓库列表 =====
async function getWarehouses() {
  const stored = await chrome.storage.local.get("erp_token");
  if (!stored.erp_token) {
    return { success: false, error: "请先登录 ERP 账号" };
  }
  console.log("[getWarehouses] 走 /erp/warehouses");
  return await requestApi("/erp/warehouses");
}

// ===== 登录 ERP =====
async function erpLogin(username, password) {
  try {
    const res = await fetch(API_URL + "/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (data.code === 0 && data.data?.token) {
      await chrome.storage.local.set({
        erp_token: data.data.token,
        erp_user: data.data.user
      });
      console.log("✅ [Background] 登录成功");
      return { success: true, data: data.data };
    }
    return { success: false, error: data.msg || "登录失败" };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

// ===== 登出 ERP =====
async function erpLogout() {
  await chrome.storage.local.remove(["erp_token", "erp_user"]);
  console.log("✅ [Background] 已登出");
  return { success: true };
}

// ===== 获取当前登录用户 =====
async function getCurrentUser() {
  const stored = await chrome.storage.local.get(["erp_token", "erp_user"]);
  if (!stored.erp_token) return { success: true, user: null };
  return { success: true, user: stored.erp_user || null, token: stored.erp_token };
}

// ===== 一键跟卖 =====
async function followSell(msg) {
  console.log("[跟卖] 开始 SKU:", msg.sku, "price:", msg.price);

  try {
    // 必须登录才能跟卖
    const stored = await chrome.storage.local.get("erp_token");
    if (!stored.erp_token) {
      return {
        success: false,
        error: "请先登录 ERP 账号才能跟卖"
      };
    }

    // Step 1：获取图片
    console.log("[跟卖] Step 1: 获取竞品图片...");
    const images = await getProductImages(msg.sku);
    console.log("[跟卖] 获取到图片:", images.length, "张");

    // Step 2：强制走新版接口（用用户自己的密钥）
    console.log("[跟卖] Step 2: 调用 /erp/follow-sell");
    const importResult = await requestApi("/erp/follow-sell", {
      method: "POST",
      body: JSON.stringify({
        sku: msg.sku,
        price: msg.price,
        name: msg.name || "",
        quantity: msg.quantity || null,
        warehouse_id: msg.warehouse_id || null,
        images: images
      })
    });

    console.log("[跟卖] 返回:", JSON.stringify(importResult).slice(0, 300));

    if (!importResult.success) {
      return {
        success: false,
        status: importResult.status || 500,
        error: importResult.error || "跟卖失败"
      };
    }

    const apiData = importResult.data;

    if (apiData?.code === 202) {
      return {
        success: true,
        status: 202,
        data: {
          code: 202,
          msg: "商品创建中，请稍后在 Ozon 后台查看",
          data: {
            task_id: apiData?.data?.task_id,
            offer_id: apiData?.data?.offer_id,
            sku: msg.sku,
            imageCount: images.length,
            status: "processing"
          }
        }
      };
    }

    if (apiData?.code === 0) {
      return {
        success: true,
        status: 200,
        data: {
          code: 0,
          msg: "跟卖成功",
          data: {
            product_id: apiData?.data?.product_id,
            offer_id: apiData?.data?.offer_id,
            sku: msg.sku,
            price: msg.price,
            imageCount: images.length,
            imageUploaded: apiData?.data?.imageUploaded,
            uploadedCount: apiData?.data?.uploadedCount,
            stockSet: apiData?.data?.stockSet,
            status: "completed"
          }
        }
      };
    }

    return {
      success: false,
      status: 500,
      error: apiData?.msg || "跟卖失败"
    };

  } catch (e) {
    console.error("[跟卖] 异常:", e.message);
    return { success: false, status: 500, error: e.message };
  }
}

// ===== Chrome Message Handler =====
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  console.log("📨 [Background] 收到消息:", msg.action);

  (async function () {
    try {
      if (msg.action === "querySingle")    return await querySingle(msg.id);
      if (msg.action === "queryItems")     return await queryItems(msg.ids);
      if (msg.action === "getWarehouses")  return await getWarehouses();
      if (msg.action === "followSell")     return await followSell(msg);
      if (msg.action === "toggleFloating") return { success: true };
      if (msg.action === "erpLogin")       return await erpLogin(msg.username, msg.password);
      if (msg.action === "erpLogout")      return await erpLogout();
      if (msg.action === "getUser")        return await getCurrentUser();
      return { success: false, error: "未知 action" };
    } catch (e) {
      return { success: false, error: e.message };
    }
  })().then(function (result) {
    console.log("📤 [Background] 返回:", result);
    sendResponse(result);
  });

  return true;
});

// ===== 点击插件图标 =====
chrome.action.onClicked.addListener(function (tab) {
  chrome.tabs.sendMessage(tab.id, { action: "toggleFloating" }, function () {
    if (chrome.runtime.lastError) {
      console.log("❌ 发送失败:", chrome.runtime.lastError.message);
    }
  });
});
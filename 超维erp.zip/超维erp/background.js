console.log("✅ [Background] 超维 ERP v6.0 已启动");

const API_URL = "https://ozon.chaowei.online";

// ===== 统一请求函数 =====
async function requestApi(path, options) {
  options = options || {};
  try {
    const url = API_URL + path;
    console.log("🌐 [Background] 请求:", url);
    const stored = await chrome.storage.local.get("erp_token");
    const userToken = stored.erp_token || null;
    const controller = new AbortController();
    const fetchTimer = setTimeout(() => controller.abort(), 120000);
    let res;
    try {
      res = await fetch(url, {
        method: options.method || "GET",
        headers: {
          "Content-Type": "application/json",
          ...(userToken ? { "Authorization": "Bearer " + userToken } : {})
        },
        body: options.body || undefined,
        signal: controller.signal
      });
    } finally { clearTimeout(fetchTimer); }
    const text = await res.text();
    console.log("📥 [Background] 状态:", res.status, path);
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch (e) {
      return { success: false, status: res.status, error: "JSON 解析失败" };
    }
    if (!res.ok) return { success: false, status: res.status, error: data?.msg || ("HTTP " + res.status), data };
    return { success: true, status: res.status, data };
  } catch (e) {
    if (e.name === "AbortError") return { success: false, error: "请求超时" };
    return { success: false, error: e.message };
  }
}

// ===== Seller Portal 通讯 =====
async function ensureSellerTab(timeoutMs = 20000) {
  const queryTabs = () => chrome.tabs.query({ url: "https://seller.ozon.ru/*" });
  const pickReadyTab = (list) =>
    list.find(t => t.status === "complete" && t.url?.includes("/app/"))
    || list.find(t => t.status === "complete")
    || null;
  let tabs = await queryTabs();
  let ready = pickReadyTab(tabs);
  if (ready) return ready;
  if (tabs.length) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      await new Promise(r => setTimeout(r, 500));
      tabs = await queryTabs();
      ready = pickReadyTab(tabs);
      if (ready) return ready;
      if (tabs.length === 0) break;
    }
  }
  const created = await chrome.tabs.create({ url: "https://seller.ozon.ru/app/products", active: false, pinned: true });
  const createDeadline = Date.now() + timeoutMs;
  while (Date.now() < createDeadline) {
    await new Promise(r => setTimeout(r, 500));
    try { const t = await chrome.tabs.get(created.id); if (t.status === "complete") return t; }
    catch { throw new Error("seller.ozon.ru tab 已被关闭"); }
  }
  throw new Error("seller.ozon.ru tab 加载超时");
}

async function fetchSellerPortal(path, body, timeoutMsOrOpts = 30000) {
  const opts = typeof timeoutMsOrOpts === "number" ? { timeoutMs: timeoutMsOrOpts } : (timeoutMsOrOpts || {});
  const timeoutMs = opts.timeoutMs || 30000;
  const urlPrefix = opts.urlPrefix !== undefined ? opts.urlPrefix : "/api/v1";
  const pageType = opts.pageType || "products";
  const targetTab = await ensureSellerTab();
  const scCookies = await chrome.cookies.getAll({ url: "https://seller.ozon.ru/", name: "sc_company_id" });
  const companyId = scCookies[0]?.value || "";
  if (!companyId) throw new Error("sc_company_id 未找到，请先登录 seller.ozon.ru");

  const doFetch = async (apiPath, reqBody, xCompanyId, timeout, prefix, pageTypeHdr) => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const resp = await fetch("https://seller.ozon.ru" + (prefix || "/api/v1") + apiPath, {
        method: "POST", signal: controller.signal, credentials: "include",
        headers: {
          "accept": "application/json, text/plain, */*", "content-type": "application/json",
          "x-o3-app-name": "seller-ui", "x-o3-company-id": xCompanyId,
          "x-o3-language": "zh-Hans", "x-o3-page-type": pageTypeHdr || "products"
        },
        body: JSON.stringify(reqBody)
      });
      clearTimeout(timer);
      if (resp.redirected && (resp.url.includes("/signin") || resp.url.includes("/login")))
        return { ok: false, status: 401, error: "Cookie 已过期" };
      const text = await resp.text();
      if (!resp.ok) return { ok: false, status: resp.status, error: `请求失败 (${resp.status})` };
      let data;
      try { data = text ? JSON.parse(text) : {}; } catch (e) { return { ok: false, error: "JSON解析失败" }; }
      return { ok: true, data };
    } catch (e) {
      clearTimeout(timer);
      if (e.name === "AbortError") return { ok: false, error: `超时` };
      return { ok: false, error: e.message || String(e) };
    }
  };

  const results = await Promise.race([
    chrome.scripting.executeScript({
      target: { tabId: targetTab.id }, func: doFetch,
      args: [path, body, companyId, timeoutMs, urlPrefix, pageType], world: "MAIN"
    }),
    new Promise((_, reject) => setTimeout(() => reject(new Error("executeScript 超时")), timeoutMs + 5000))
  ]);
  const r = results?.[0]?.result;
  if (!r) throw new Error("executeScript 未返回结果");
  if (!r.ok) throw new Error(r.error || "unknown");
  return r.data;
}

// ===== 获取竞品图片 =====
async function getProductImages(sku) {
  try {
    const scCookies = await chrome.cookies.getAll({ url: "https://seller.ozon.ru/", name: "sc_company_id" });
    const companyId = scCookies[0]?.value;
    if (!companyId) { console.warn("[图片] 未登录 seller.ozon.ru"); return []; }
    const searchResp = await fetchSellerPortal("/search", {
      company_id: companyId,
      filter: { children_nodes: { children_nodes: [{ input_leaf: { sku: { values: [String(sku)] } } }], operator: "AND" } },
      pagination: { limit: "1" }
    }, { urlPrefix: "/api/v1", pageType: "products", timeoutMs: 30000 });
    const variant = searchResp?.variants?.[0];
    if (!variant) { console.warn("[图片] 没找到竞品"); return []; }
    const images = [];
    if (variant.main_image) images.push(variant.main_image);
    if (Array.isArray(variant.secondary_images)) {
      variant.secondary_images.forEach(img => { if (img && !images.includes(img)) images.push(img); });
    }
    console.log("[图片] 获取到图片:", images.length, "张");
    return images;
  } catch (e) {
    console.warn("[图片] 获取图片失败:", e.message);
    return [];
  }
}

// ===== 获取竞品基础信息（品牌等）=====
async function getProductVariantInfo(sku) {
  try {
    const scCookies = await chrome.cookies.getAll({ url: "https://seller.ozon.ru/", name: "sc_company_id" });
    const companyId = scCookies[0]?.value;
    if (!companyId) return null;
    const searchResp = await fetchSellerPortal("/search", {
      company_id: companyId,
      filter: { children_nodes: { children_nodes: [{ input_leaf: { sku: { values: [String(sku)] } } }], operator: "AND" } },
      pagination: { limit: "1" }
    }, { urlPrefix: "/api/v1", pageType: "products", timeoutMs: 30000 });
    const variant = searchResp?.variants?.[0];
    if (!variant) return null;
    return {
      variant_name: variant.variant_name || "",
      brand_name: variant.brand_name || "",
      brand_id: variant.brand_id || "",
      barcodes: variant.barcodes || [],
      variant_id: variant.variant_id || ""
    };
  } catch (e) {
    console.warn("[variant] 获取失败:", e.message);
    return null;
  }
}

// ===== 从前台商品页抓取简介+标签+富内容 =====
async function getProductFrontPageData(sku) {
  try {
    // 找到 ozon.ru 的 tab
    const tabs = await chrome.tabs.query({ url: "https://www.ozon.ru/*" });
    let targetTab = tabs.find(t => t.url && t.url.includes(String(sku)));
    if (!targetTab) targetTab = tabs[0];
    if (!targetTab) {
      console.warn("[前台抓取] 没有 ozon.ru tab");
      return null;
    }

    const extractFunc = async (targetSku) => {
      try {
        // 1. 从 JSON-LD 抓简介和名称
        let name = "";
        let description = "";
        const scripts = Array.from(document.querySelectorAll("script"));
        for (const s of scripts) {
          const txt = s.textContent || "";
          if (!txt.includes('"@type":"Product"')) continue;
          try {
            const json = JSON.parse(txt);
            if (json && json["@type"] === "Product") {
              name = json.name || "";
              description = json.description || "";
              break;
            }
          } catch (e) {}
        }

        // 2. 抓标签
        const text = document.body.innerText || "";
        const tags = [...new Set(
          (text.match(/#[^\s#]+/g) || []).map(function(t) { return t.trim(); })
        )];

        // 3. 抓富内容
        let richContent = null;
        try {
          const productUrl = "/product/" + location.pathname.split("/product/")[1];
          const encodedUrl = encodeURIComponent(productUrl + "?layout_container=pdpPage2column&layout_page_index=2");
          const resp = await fetch("https://www.ozon.ru/api/entrypoint-api.bx/page/json/v2?url=" + encodedUrl);
          const data = await resp.json();
          const widgetStateId = Object.keys(data.widgetStates || {}).find(function(key) {
            const val = data.widgetStates[key];
            return typeof val === "string" && (val.includes("raShowcase") || val.includes("richAnnotationType"));
          });
          if (widgetStateId) {
            const rawVal = data.widgetStates[widgetStateId];
            const parsed = typeof rawVal === "string" ? JSON.parse(rawVal) : rawVal;
            richContent = parsed?.richAnnotationJson || null;
          }
        } catch (e) {
          // 富内容抓取失败不阻塞
        }

        return { ok: true, name, description, tags, richContent };
      } catch (e) {
        return { ok: false, error: e.message };
      }
    };

    const results = await Promise.race([
      chrome.scripting.executeScript({
        target: { tabId: targetTab.id },
        func: extractFunc,
        args: [sku],
        world: "MAIN"
      }),
      new Promise((_, reject) => setTimeout(() => reject(new Error("前台抓取超时")), 30000))
    ]);

    const result = results?.[0]?.result;
    if (!result?.ok) {
      console.warn("[前台抓取] 失败:", result?.error);
      return null;
    }

    console.log("[前台抓取] 成功:", {
      name: result.name?.slice(0, 30),
      desc: result.description?.slice(0, 30),
      tags: result.tags?.length,
      hasRichContent: !!result.richContent
    });

    return result;
  } catch (e) {
    console.warn("[前台抓取] 异常:", e.message);
    return null;
  }
}

// ===== 保存草稿（回写品牌+标签+富内容）=====
async function saveDraftAttributes(productId, draftData) {
  try {
    const targetTab = await ensureSellerTab();

    const doSave = async (pid, data) => {
      try {
        const companyId = document.cookie.match(/sc_company_id=(\d+)/)?.[1] || "";
        const guid = crypto.randomUUID();

        const values = {
          id: pid,
          name: data.name || undefined,
          vendorValue: data.brandName || undefined,
          vendorId: data.brandId || undefined,
          "attribute#23171": data.tags || undefined,
          "attribute#11254": data.richContent || undefined
        };

        // 清除 undefined 字段
        Object.keys(values).forEach(function(k) {
          if (values[k] === undefined || values[k] === null || values[k] === "") delete values[k];
        });

        const draftBody = {
          data: {
            values: JSON.stringify(values),
            form_state: "edit",
            adding_products_mode: "One",
            is_adding_several_products_mode_allowed: false,
            barcodes: [],
            default_attrs_for_send_data: []
          },
          guid: guid,
          navigation: {
            route_path: "/products/" + pid + "/edit/general-info",
            product_id: pid
          },
          type: "EDIT_SINGLE"
        };

        const resp = await fetch("https://seller.ozon.ru/api/draft_storage/create", {
          method: "POST",
          credentials: "include",
          headers: {
            "content-type": "application/json",
            "x-o3-app-name": "seller-ui",
            "x-o3-company-id": companyId,
            "x-o3-language": "zh-Hans",
            "x-o3-page-type": "products"
          },
          body: JSON.stringify(draftBody)
        });

        const result = await resp.json();
        return { ok: resp.ok, data: result };
      } catch (e) {
        return { ok: false, error: e.message };
      }
    };

    const results = await Promise.race([
      chrome.scripting.executeScript({
        target: { tabId: targetTab.id },
        func: doSave,
        args: [productId, draftData],
        world: "MAIN"
      }),
      new Promise((_, reject) => setTimeout(() => reject(new Error("草稿保存超时")), 60000))
    ]);

    const result = results?.[0]?.result;
    if (!result?.ok) {
      console.warn("[草稿] 保存失败:", result?.error);
      return { ok: false, error: result?.error };
    }

    console.log("[草稿] 保存成功");
    return { ok: true };
  } catch (e) {
    console.warn("[草稿] 异常:", e.message);
    return { ok: false, error: e.message };
  }
}

// ===== 图片水印处理 =====
async function addWatermarkToImages(imageUrls, wmConfig) {
  if (!imageUrls || imageUrls.length === 0) return imageUrls;
  console.log("[水印] 开始处理", imageUrls.length, "张图片");
  const targetTab = await ensureSellerTab();

  const processImages = async (urls, config) => {
    const results = [];
    for (const url of urls) {
      try {
        const resp = await fetch(url);
        if (!resp.ok) { results.push(url); continue; }
        const blob = await resp.blob();
        const imageBitmap = await createImageBitmap(blob);
        const canvas = new OffscreenCanvas(imageBitmap.width, imageBitmap.height);
        const ctx = canvas.getContext("2d");
        ctx.drawImage(imageBitmap, 0, 0);
        // 像素噪点
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;
        for (let i = 0; i < 800; i++) {
          const idx = Math.floor(Math.random() * (data.length / 4)) * 4;
          data[idx] = Math.min(255, Math.max(0, data[idx] + Math.floor(Math.random() * 4) - 2));
          data[idx+1] = Math.min(255, Math.max(0, data[idx+1] + Math.floor(Math.random() * 4) - 2));
          data[idx+2] = Math.min(255, Math.max(0, data[idx+2] + Math.floor(Math.random() * 4) - 2));
        }
        ctx.putImageData(imageData, 0, 0);
        // 水印图片
        if (config && config.imageBase64) {
          try {
            const wmResp = await fetch(config.imageBase64);
            const wmBlob = await wmResp.blob();
            const wmBitmap = await createImageBitmap(wmBlob);
            const wmWidth = canvas.width * ((config.size || 15) / 100);
            const wmHeight = wmBitmap.height * (wmWidth / wmBitmap.width);
            const paddingPercent = config.padding !== undefined ? config.padding : 2;
            const padding = Math.floor(canvas.width * (paddingPercent / 100));
            const position = config.position || "bottom-right";
            let x = 0, y = 0;
            switch (position) {
              case "top-left": x = padding; y = padding; break;
              case "top-right": x = canvas.width - wmWidth - padding; y = padding; break;
              case "bottom-left": x = padding; y = canvas.height - wmHeight - padding; break;
              case "bottom-right": x = canvas.width - wmWidth - padding; y = canvas.height - wmHeight - padding; break;
              case "center": x = (canvas.width - wmWidth) / 2; y = (canvas.height - wmHeight) / 2; break;
              default: x = canvas.width - wmWidth - padding; y = canvas.height - wmHeight - padding;
            }
            ctx.globalAlpha = (config.opacity || 60) / 100;
            ctx.drawImage(wmBitmap, x, y, wmWidth, wmHeight);
            ctx.globalAlpha = 1.0;
          } catch (wmErr) {}
        }
        const outputBlob = await canvas.convertToBlob({ type: "image/jpeg", quality: 0.92 });
        const reader = new FileReader();
        const base64 = await new Promise((resolve) => { reader.onload = () => resolve(reader.result); reader.readAsDataURL(outputBlob); });
        results.push(base64);
      } catch (e) { results.push(url); }
    }
    return results;
  };

  try {
    const scriptResults = await Promise.race([
      chrome.scripting.executeScript({ target: { tabId: targetTab.id }, func: processImages, args: [imageUrls, wmConfig], world: "MAIN" }),
      new Promise((_, reject) => setTimeout(() => reject(new Error("水印处理超时")), 90000))
    ]);
    const processedImages = scriptResults?.[0]?.result;
    if (!processedImages || !Array.isArray(processedImages)) return imageUrls;
    console.log("[水印] 完成，共", processedImages.length, "张");
    return processedImages;
  } catch (e) {
    console.warn("[水印] 失败，使用原图:", e.message);
    return imageUrls;
  }
}

// ===== 查询 =====
async function querySingle(id) {
  const stored = await chrome.storage.local.get("erp_token");
  if (!stored.erp_token) return { success: false, error: "请先登录" };
  return await requestApi("/erp/query/" + id);
}

async function queryItems(ids) {
  const uniqueIds = [...new Set((ids || []).map(i => String(i).trim()).filter(Boolean))];
  if (!uniqueIds.length) return { success: false, error: "ids 为空" };
  const stored = await chrome.storage.local.get("erp_token");
  if (!stored.erp_token) return { success: false, error: "请先登录" };
  return await requestApi("/erp/full/batch", { method: "POST", body: JSON.stringify({ ids: uniqueIds }) });
}

async function getWarehouses() {
  const stored = await chrome.storage.local.get("erp_token");
  if (!stored.erp_token) return { success: false, error: "请先登录" };
  return await requestApi("/erp/warehouses");
}

async function getStoreWarehouses(storeId) {
  const stored = await chrome.storage.local.get("erp_token");
  if (!stored.erp_token) return { success: false, error: "请先登录" };
  return await requestApi("/erp/store-warehouses", { method: "POST", body: JSON.stringify({ storeId }) });
}

async function getStores() {
  const stored = await chrome.storage.local.get("erp_token");
  if (!stored.erp_token) return { success: false, error: "请先登录" };
  return await requestApi("/user/stores");
}

async function getWatermarks() {
  const stored = await chrome.storage.local.get("erp_token");
  if (!stored.erp_token) return { success: false, error: "请先登录" };
  return await requestApi("/user/watermark");
}

async function erpLogin(username, password) {
  try {
    const res = await fetch(API_URL + "/auth/login", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (data.code === 0 && data.data?.token) {
      await chrome.storage.local.set({ erp_token: data.data.token, erp_user: data.data.user });
      return { success: true, data: data.data };
    }
    return { success: false, error: data.msg || "登录失败" };
  } catch (e) { return { success: false, error: e.message }; }
}

async function erpLogout() {
  await chrome.storage.local.remove(["erp_token", "erp_user"]);
  return { success: true };
}

async function getCurrentUser() {
  const stored = await chrome.storage.local.get(["erp_token", "erp_user"]);
  if (!stored.erp_token) return { success: true, user: null };
  return { success: true, user: stored.erp_user || null };
}

async function scheduleStockTask(task) {
  const alarmName = "stock_" + Date.now() + "_" + task.product_id;
  await chrome.storage.local.set({ ["stockTask:" + alarmName]: task });
  await chrome.alarms.create(alarmName, { delayInMinutes: task.delay_minutes });
  console.log("⏰ [库存] 延迟任务:", alarmName, task.delay_minutes, "分钟后");
  return alarmName;
}

async function pollFollowSellTask(taskId, maxRetry, extra) {
  maxRetry = maxRetry || 24;
  extra = extra || {};

  for (let i = 0; i < maxRetry; i++) {
    await new Promise(function(resolve) { setTimeout(resolve, 10000); });

    console.log("[check-task] 第", i + 1, "次查询 task:", taskId, extra);

    const result = await requestApi("/erp/check-task", {
      method: "POST",
      body: JSON.stringify({
        task_id: taskId,
        storeId: extra.storeId || null,
        clientId: extra.clientId || null,
        apiKey: extra.apiKey || null
      })
    });

    if (result?.success && result.data?.code === 0) return result;

    // 202 继续轮询
    if (result?.status === 202 || result?.data?.code === 202) continue;

    // 其他错误直接返回
    return result;
  }

  return { success: false, error: "任务轮询超时" };
}

// ===== 一键跟卖（终极版）=====
async function followSell(msg) {
  console.log("[跟卖] 开始 SKU:", msg.sku, "price:", msg.price);
  try {
    const stored = await chrome.storage.local.get("erp_token");
    if (!stored.erp_token) return { success: false, error: "请先登录" };

    // Step 1：获取图片
    console.log("[跟卖] Step 1: 获取竞品图片...");
    const images = await getProductImages(msg.sku);
    console.log("[跟卖] 图片:", images.length, "张");

    // Step 1.5：获取竞品基础信息（品牌等）
    console.log("[跟卖] Step 1.5: 获取品牌信息...");
    const variantInfo = await getProductVariantInfo(msg.sku);
    console.log("[跟卖] 品牌:", variantInfo?.brand_name || "未获取到");

    // Step 1.8：获取前台数据（简介+标签+富内容）
    console.log("[跟卖] Step 1.8: 获取前台数据...");
    const frontData = await getProductFrontPageData(msg.sku);
    console.log("[跟卖] 前台:", frontData ? "成功" : "失败");

    // Step 2：水印处理
    let processedImages = images;
    if (images.length > 0 && msg.enableWatermark !== false) {
  console.log("[跟卖] Step 2: 获取水印配置...");
  const wmResult = await requestApi("/user/watermark");
  let wmConfig = null;
  if (wmResult?.success && wmResult.data?.code === 0) {
    const wms = wmResult.data.data.watermarks || [];
    if (
      typeof msg.watermarkIndex === "number" &&
      msg.watermarkIndex >= 0 &&
      wms[msg.watermarkIndex]
    ) {
      wmConfig = wms[msg.watermarkIndex];
    } else {
      wmConfig = wms[0] || null;
    }
  }
  console.log("[跟卖] Step 2.5: 处理图片...");
  processedImages = await addWatermarkToImages(images, wmConfig);
  console.log("[跟卖] 处理完成:", processedImages.length, "张");
}

    // Step 3：调用 Worker 建品
    console.log("[跟卖] Step 3: 调用 /erp/follow-sell");
    const importResult = await requestApi("/erp/follow-sell", {
      method: "POST",
      body: JSON.stringify({
        sku: msg.sku, price: msg.price,
        name: frontData?.name || variantInfo?.variant_name || msg.name || "",
        quantity: msg.quantity || null,
        warehouse_id: msg.warehouse_id || null,
        storeIds: msg.storeIds || [],
        warehouseIds: msg.warehouseIds || {},
        stock_delay: msg.stock_delay || 0,
        images: processedImages
      })
    });

    console.log("[跟卖] 返回:", JSON.stringify(importResult).slice(0, 300));
    if (!importResult.success) return { success: false, error: importResult.error || "跟卖失败" };
    const apiData = importResult.data;

    // ===== 旧版 202 =====
    if (apiData?.code === 202) {
      const taskId = apiData?.data?.task_id;
      console.log("[跟卖] 202 轮询:", taskId);
      const finalResult = await pollFollowSellTask(taskId);
      if (finalResult?.success && finalResult.data?.code === 0) {
        const fd = finalResult.data.data || {};
        // Step 4：回写属性
        await tryWriteAttributes(fd.product_id, variantInfo, frontData);
        return { success: true, status: 200, data: { code: 0, msg: "跟卖成功", data: { ...fd, status: "completed" } } };
      }
      return { success: true, status: 202, data: { code: 202, msg: "商品创建中", data: apiData?.data } };
    }

    // ===== 新版多店铺 =====
    if (apiData?.code === 0) {
      const payload = apiData.data || {};
      const storeResults = Array.isArray(payload.results) ? payload.results : [];

      if (storeResults.length > 0) {
        const finalResults = [];
        for (let i = 0; i < storeResults.length; i++) {
          const r = storeResults[i];
          if (r.ok && r.status === "completed") {
            if (r.pendingStock) await scheduleStockTask(r.pendingStock);
            // Step 4：回写属性
            await tryWriteAttributes(r.product_id, variantInfo, frontData);
            finalResults.push(r);
            continue;
          }
          if (r.ok && r.status === "processing" && r.task_id) {
  console.log("[跟卖] 店铺", r.storeName, "轮询:", r.task_id);

  const finalResult = await pollFollowSellTask(r.task_id, 24, {
    storeId: r.storeId
  });

  if (finalResult?.success && finalResult.data?.code === 0) {
    const d = finalResult.data.data || {};
    await tryWriteAttributes(d.product_id, variantInfo, frontData);
    finalResults.push({
      ...r,
      status: "completed",
      product_id: d.product_id,
      imageUploaded: d.imageUploaded,
      uploadedCount: d.uploadedCount,
      stockSet: d.stockSet
    });
  } else {
    finalResults.push({
      ...r,
      ok: false,
      status: "failed",
      msg: finalResult?.error || finalResult?.data?.msg || "轮询失败"
    });
  }

  continue;
}
          finalResults.push(r);
        }

        const pendingStocks = Array.isArray(payload.pendingStocks) ? payload.pendingStocks : [];
        for (const ps of pendingStocks) await scheduleStockTask(ps);

        return {
          success: true, status: 200,
          data: {
            code: 0, msg: apiData.msg || "跟卖完成",
            data: {
              sku: msg.sku, price: msg.price, imageCount: processedImages.length,
              results: finalResults,
              successCount: finalResults.filter(x => x.ok).length,
              failCount: finalResults.filter(x => !x.ok).length,
              status: finalResults.every(x => x.status === "completed") ? "completed" : "partial"
            }
          }
        };
      }

      // 旧版兼容
      const info = payload || {};
      if (info.stockDelayed && info.pendingStock) await scheduleStockTask(info.pendingStock);
      if (info.product_id) await tryWriteAttributes(info.product_id, variantInfo, frontData);
      return { success: true, status: 200, data: { code: 0, msg: "跟卖成功", data: { ...info, status: "completed" } } };
    }

    return { success: false, error: apiData?.msg || "跟卖失败" };
  } catch (e) {
    console.error("[跟卖] 异常:", e.message);
    return { success: false, error: e.message };
  }
}

// ===== 回写属性（品牌+标签+富内容）=====
async function tryWriteAttributes(productId, variantInfo, frontData) {
  if (!productId) return;
  console.log("[属性回写] product_id:", productId);

  try {
    const draftData = {};

    // 品牌
    if (variantInfo?.brand_name) {
      draftData.brandName = variantInfo.brand_name;
      draftData.brandId = String(variantInfo.brand_id || "");
    }

    // 名称
    if (frontData?.name) draftData.name = frontData.name;
    else if (variantInfo?.variant_name) draftData.name = variantInfo.variant_name;

    // 标签
    if (frontData?.tags && frontData.tags.length > 0) {
      draftData.tags = frontData.tags.join(" ");
    }

    // 富内容
    if (frontData?.richContent) {
      draftData.richContent = JSON.stringify(frontData.richContent);
    }

    if (Object.keys(draftData).length === 0) {
      console.log("[属性回写] 没有可回写的数据");
      return;
    }

    // 等待商品在 Ozon 系统里稳定
    await new Promise(r => setTimeout(r, 3000));

    const result = await saveDraftAttributes(productId, draftData);
    if (result.ok) {
      console.log("✅ [属性回写] 成功");
    } else {
      console.warn("❌ [属性回写] 失败:", result.error);
    }
  } catch (e) {
    console.warn("[属性回写] 异常:", e.message);
  }
}

// ===== 延迟库存 =====
chrome.alarms.onAlarm.addListener(async function(alarm) {
  if (!alarm.name || !alarm.name.startsWith("stock_")) return;
  const storageKey = "stockTask:" + alarm.name;
  const stored = await chrome.storage.local.get(storageKey);
  const task = stored[storageKey];
  if (!task) return;
  try {
    const result = await requestApi("/erp/set-stock", {
      method: "POST",
      body: JSON.stringify({ product_id: task.product_id, quantity: task.quantity, warehouse_id: task.warehouse_id, clientId: task.clientId, apiKey: task.apiKey })
    });
    console.log(result?.success ? "✅ 延迟库存成功" : "❌ 延迟库存失败");
  } catch (e) { console.error("❌ 延迟库存异常:", e.message); }
  await chrome.storage.local.remove(storageKey);
});

// ===== Chrome Message Handler =====
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  console.log("📨 [Background] 收到:", msg.action);

  (async function() {
    try {
      if (msg.action === "querySingle") {
        return await querySingle(msg.id);
      }

      if (msg.action === "queryItems") {
        return await queryItems(msg.ids);
      }

      if (msg.action === "getWarehouses") {
        return await getWarehouses();
      }

      if (msg.action === "getStores") {
        return await getStores();
      }

      if (msg.action === "getStoreWarehouses") {
        return await getStoreWarehouses(msg.storeId);
      }

      if (msg.action === "getWatermarks") {
        return await getWatermarks();
      }

      if (msg.action === "saveFavorites") {
        return await requestApi("/erp/favorites/save", {
          method: "POST",
          body: JSON.stringify({ favorites: msg.favorites || [] })
        });
      }

      if (msg.action === "getFavorites") {
        return await requestApi("/erp/favorites");
      }

      // ✅ 新增：打开上传窗口
      if (msg.action === "openUploadWindow") {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (tab?.id) {
      await chrome.tabs.sendMessage(tab.id, {
        action: "openUploadPanel",
        sku: msg.sku || "",
        name: msg.name || "",
        brand: msg.brand || ""
      });
    }
  } catch (e) {
    console.warn("[上货面板] 发送失败:", e.message);
  }
  return { success: true };
}

      if (msg.action === "followSell") {
        return await followSell(msg);
      }

      if (msg.action === "toggleFloating") {
        return { success: true };
      }

      if (msg.action === "erpLogin") {
        return await erpLogin(msg.username, msg.password);
      }

      if (msg.action === "erpLogout") {
        return await erpLogout();
      }

      if (msg.action === "getUser") {
        return await getCurrentUser();
      }

      return { success: false, error: "未知 action" };
    } catch (e) {
      return { success: false, error: e.message };
    }
  })().then(function(result) {
    console.log("📤 [Background] 返回:", result);
    sendResponse(result);
  });

  return true;
});

// ===== Chrome Message Handler =====
// ===== Chrome Message Handler =====
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  console.log("📨 [Background] 收到:", msg.action);

  (async function() {
    try {
      if (msg.action === "querySingle") {
        return await querySingle(msg.id);
      }
      if (msg.action === "queryItems") {
        return await queryItems(msg.ids);
      }
      if (msg.action === "getWarehouses") {
        return await getWarehouses();
      }
      if (msg.action === "getStores") {
        return await getStores();
      }
      if (msg.action === "getStoreWarehouses") {
        return await getStoreWarehouses(msg.storeId);
      }
      if (msg.action === "getWatermarks") {
        return await getWatermarks();
      }
      if (msg.action === "saveFavorites") {
        return await requestApi("/erp/favorites/save", {
          method: "POST",
          body: JSON.stringify({ favorites: msg.favorites || [] })
        });
      }
      if (msg.action === "getFavorites") {
        return await requestApi("/erp/favorites");
      }
      if (msg.action === "openUploadWindow") {
        try {
          const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
          const tab = tabs[0];
          if (tab?.id) {
            await chrome.tabs.sendMessage(tab.id, {
              action: "openUploadPanel",
              sku: msg.sku || "",
              name: msg.name || "",
              brand: msg.brand || ""
            });
          }
        } catch (e) {
          console.warn("[上货面板] 发送失败:", e.message);
        }
        return { success: true };
      }
      if (msg.action === "followSell") {
        return await followSell(msg);
      }
      if (msg.action === "toggleFloating") {
        return { success: true };
      }
      if (msg.action === "erpLogin") {
        return await erpLogin(msg.username, msg.password);
      }
      if (msg.action === "erpLogout") {
        return await erpLogout();
      }
      if (msg.action === "getUser") {
        return await getCurrentUser();
      }
      return { success: false, error: "未知 action" };
    } catch (e) {
      return { success: false, error: e.message };
    }
  })().then(function(result) {
    console.log("📤 [Background] 返回:", result);
    sendResponse(result);
  });

  return true;
});

// ===== 登录态同步：监听 storage 变化，广播给所有 tab =====
chrome.storage.onChanged.addListener(function(changes, area) {
  if (area !== "local") return;
  if (!changes.erp_token && !changes.erp_user) return;

  chrome.tabs.query({}, function(tabs) {
    var msg = {
      action: "erpAuthChanged",
      token: changes.erp_token ? changes.erp_token.newValue : undefined,
      user: changes.erp_user ? changes.erp_user.newValue : undefined,
      loggedOut: changes.erp_token && !changes.erp_token.newValue
    };
    tabs.forEach(function(tab) {
      try {
        chrome.tabs.sendMessage(tab.id, msg, function() {
          if (chrome.runtime.lastError) { /* ignore */ }
        });
      } catch(e) {}
    });
  });
});
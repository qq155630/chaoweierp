console.log("✅ [Background] Ozon ERP Background 已启动");

const API_URL = "https://ozon.chaowei.online";

// ===== 统一请求函数（只用 Bearer Token）=====
async function requestApi(path, options) {
  options = options || {};
  try {
    const url = API_URL + path;
    console.log("🌐 [Background] 请求:", url);

    const stored = await chrome.storage.local.get("erp_token");
    const userToken = stored.erp_token || null;

    const controller = new AbortController();
    const fetchTimer = setTimeout(() => controller.abort(), 120000);

    let res;
    try {
      res = await fetch(url, {
        method: options.method || "GET",
        headers: {
          "Content-Type": "application/json",
          ...(userToken ? { "Authorization": "Bearer " + userToken } : {})
        },
        body: options.body || undefined,
        signal: controller.signal
      });
    } finally {
      clearTimeout(fetchTimer);
    }

    const text = await res.text();
    console.log("📥 [Background] 状态:", res.status, path);

    let data = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch (e) {
      return { success: false, status: res.status, error: "JSON 解析失败：" + e.message };
    }

    if (!res.ok) {
      return { success: false, status: res.status, error: data?.msg || ("HTTP " + res.status), data };
    }

    return { success: true, status: res.status, data };
  } catch (e) {
    if (e.name === "AbortError") return { success: false, error: "请求超时（120秒）" };
    return { success: false, error: e.message };
  }
}

// ===== Seller Portal 通讯 =====
async function ensureSellerTab(timeoutMs = 20000) {
  const queryTabs = () => chrome.tabs.query({ url: "https://seller.ozon.ru/*" });
  const pickReadyTab = (list) =>
    list.find(t => t.status === "complete" && t.url?.includes("/app/"))
    || list.find(t => t.status === "complete")
    || null;

  let tabs = await queryTabs();
  let ready = pickReadyTab(tabs);
  if (ready) return ready;

  if (tabs.length) {
    const waitDeadline = Date.now() + timeoutMs;
    while (Date.now() < waitDeadline) {
      await new Promise(r => setTimeout(r, 500));
      tabs = await queryTabs();
      ready = pickReadyTab(tabs);
      if (ready) return ready;
      if (tabs.length === 0) break;
    }
  }

  console.log("[ensureSellerTab] 后台打开 seller.ozon.ru...");
  const created = await chrome.tabs.create({
    url: "https://seller.ozon.ru/app/products/copy/list",
    active: false,
    pinned: true
  });

  const createDeadline = Date.now() + timeoutMs;
  while (Date.now() < createDeadline) {
    await new Promise(r => setTimeout(r, 500));
    try {
      const t = await chrome.tabs.get(created.id);
      if (t.status === "complete") return t;
    } catch {
      throw new Error("seller.ozon.ru tab 已被关闭");
    }
  }
  throw new Error("seller.ozon.ru tab 加载超时");
}

async function fetchSellerPortal(path, body, timeoutMsOrOpts = 30000) {
  const opts = typeof timeoutMsOrOpts === "number" ? { timeoutMs: timeoutMsOrOpts } : (timeoutMsOrOpts || {});
  const timeoutMs = opts.timeoutMs || 30000;
  const urlPrefix = opts.urlPrefix !== undefined ? opts.urlPrefix : "/api/v1";
  const pageType = opts.pageType || "products";

  const targetTab = await ensureSellerTab();
  const scCookies = await chrome.cookies.getAll({ url: "https://seller.ozon.ru/", name: "sc_company_id" });
  const companyId = scCookies[0]?.value || "";
  if (!companyId) throw new Error("sc_company_id 未找到，请先登录 seller.ozon.ru");

  const doFetch = async (apiPath, reqBody, xCompanyId, timeout, prefix, pageTypeHdr) => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const resp = await fetch("https://seller.ozon.ru" + (prefix || "/api/v1") + apiPath, {
        method: "POST", signal: controller.signal, credentials: "include",
        headers: {
          "accept": "application/json, text/plain, */*", "content-type": "application/json",
          "x-o3-app-name": "seller-ui", "x-o3-company-id": xCompanyId,
          "x-o3-language": "zh-Hans", "x-o3-page-type": pageTypeHdr || "products"
        },
        body: JSON.stringify(reqBody)
      });
      clearTimeout(timer);
      if (resp.redirected && (resp.url.includes("/signin") || resp.url.includes("/login"))) {
        return { ok: false, status: 401, error: "Cookie 已过期，请重新登录 seller.ozon.ru" };
      }
      const text = await resp.text();
      if (!resp.ok) return { ok: false, status: resp.status, error: `请求失败 (${resp.status}): ${text.slice(0, 200)}` };
      let data;
      try { data = text ? JSON.parse(text) : {}; } catch (e) { return { ok: false, error: "JSON解析失败" }; }
      return { ok: true, data };
    } catch (e) {
      clearTimeout(timer);
      if (e.name === "AbortError") return { ok: false, error: `超时 (${timeout}ms)` };
      return { ok: false, error: e.message || String(e) };
    }
  };

  const results = await Promise.race([
    chrome.scripting.executeScript({
      target: { tabId: targetTab.id }, func: doFetch,
      args: [path, body, companyId, timeoutMs, urlPrefix, pageType], world: "MAIN"
    }),
    new Promise((_, reject) => setTimeout(() => reject(new Error("executeScript 超时")), timeoutMs + 5000))
  ]);

  const r = results?.[0]?.result;
  if (!r) throw new Error("executeScript 未返回结果");
  if (!r.ok) throw new Error(r.error || "unknown");
  return r.data;
}

// ===== 获取竞品图片 =====
async function getProductImages(sku) {
  try {
    const scCookies = await chrome.cookies.getAll({ url: "https://seller.ozon.ru/", name: "sc_company_id" });
    const companyId = scCookies[0]?.value;
    if (!companyId) { console.warn("[图片] 未登录 seller.ozon.ru"); return []; }

    const searchResp = await fetchSellerPortal("/search", {
      company_id: companyId,
      filter: { children_nodes: { children_nodes: [{ input_leaf: { sku: { values: [String(sku)] } } }], operator: "AND" } },
      pagination: { limit: "1" }
    }, { urlPrefix: "/api/v1", pageType: "products", timeoutMs: 30000 });

    const variant = searchResp?.variants?.[0];
    if (!variant) { console.warn("[图片] 没找到竞品"); return []; }

    const images = [];
    if (variant.main_image) images.push(variant.main_image);
    if (Array.isArray(variant.secondary_images)) {
      variant.secondary_images.forEach(img => { if (img && !images.includes(img)) images.push(img); });
    }
    console.log("[图片] 获取到图片:", images.length, "张");
    return images;
  } catch (e) {
    console.warn("[图片] 获取图片失败:", e.message);
    return [];
  }
}

// ===== 图片水印处理 =====
async function addWatermarkToImages(imageUrls, wmConfig) {
  if (!imageUrls || imageUrls.length === 0) return imageUrls;
  console.log("[水印] 开始处理", imageUrls.length, "张图片");

  const targetTab = await ensureSellerTab();

  const processImages = async (urls, config) => {
    const results = [];
    for (const url of urls) {
      try {
        const resp = await fetch(url);
        if (!resp.ok) { results.push(url); continue; }
        const blob = await resp.blob();
        const imageBitmap = await createImageBitmap(blob);
        const canvas = new OffscreenCanvas(imageBitmap.width, imageBitmap.height);
        const ctx = canvas.getContext("2d");
        ctx.drawImage(imageBitmap, 0, 0);

        // 像素噪点
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;
        for (let i = 0; i < 800; i++) {
          const idx = Math.floor(Math.random() * (data.length / 4)) * 4;
          data[idx]     = Math.min(255, Math.max(0, data[idx]     + Math.floor(Math.random() * 4) - 2));
          data[idx + 1] = Math.min(255, Math.max(0, data[idx + 1] + Math.floor(Math.random() * 4) - 2));
          data[idx + 2] = Math.min(255, Math.max(0, data[idx + 2] + Math.floor(Math.random() * 4) - 2));
        }
        ctx.putImageData(imageData, 0, 0);

        // 水印图片
        if (config && config.imageBase64) {
          try {
            const wmResp = await fetch(config.imageBase64);
            const wmBlob = await wmResp.blob();
            const wmBitmap = await createImageBitmap(wmBlob);
            const wmWidth = canvas.width * ((config.size || 15) / 100);
            const wmHeight = wmBitmap.height * (wmWidth / wmBitmap.width);
            const paddingPercent = config.padding !== undefined ? config.padding : 2;
            const padding = Math.floor(canvas.width * (paddingPercent / 100));
            const position = config.position || "bottom-right";
            let x = 0, y = 0;
            switch (position) {
              case "top-left":     x = padding; y = padding; break;
              case "top-right":    x = canvas.width - wmWidth - padding; y = padding; break;
              case "bottom-left":  x = padding; y = canvas.height - wmHeight - padding; break;
              case "bottom-right": x = canvas.width - wmWidth - padding; y = canvas.height - wmHeight - padding; break;
              case "center":       x = (canvas.width - wmWidth) / 2; y = (canvas.height - wmHeight) / 2; break;
              default:             x = canvas.width - wmWidth - padding; y = canvas.height - wmHeight - padding;
            }
            ctx.globalAlpha = (config.opacity || 60) / 100;
            ctx.drawImage(wmBitmap, x, y, wmWidth, wmHeight);
            ctx.globalAlpha = 1.0;
          } catch (wmErr) { console.warn("[水印] 水印图片加载失败:", wmErr.message); }
        }

        const outputBlob = await canvas.convertToBlob({ type: "image/jpeg", quality: 0.92 });
        const reader = new FileReader();
        const base64 = await new Promise((resolve) => {
          reader.onload = () => resolve(reader.result);
          reader.readAsDataURL(outputBlob);
        });
        results.push(base64);
      } catch (e) {
        console.warn("[水印] 处理失败，使用原图:", e.message);
        results.push(url);
      }
    }
    return results;
  };

  try {
    const scriptResults = await Promise.race([
      chrome.scripting.executeScript({
        target: { tabId: targetTab.id }, func: processImages,
        args: [imageUrls, wmConfig], world: "MAIN"
      }),
      new Promise((_, reject) => setTimeout(() => reject(new Error("水印处理超时")), 90000))
    ]);
    const processedImages = scriptResults?.[0]?.result;
    if (!processedImages || !Array.isArray(processedImages)) {
      console.warn("[水印] 结果异常，使用原图"); return imageUrls;
    }
    console.log("[水印] 全部完成，共", processedImages.length, "张");
    return processedImages;
  } catch (e) {
    console.warn("[水印] 处理失败，使用原图:", e.message);
    return imageUrls;
  }
}

// ===== 查询单个商品（必须登录）=====
async function querySingle(id) {
  const stored = await chrome.storage.local.get("erp_token");
  if (!stored.erp_token) {
    return { success: false, error: "请先在插件浮窗中登录 ERP 账号" };
  }
  console.log("[querySingle] /erp/query/" + id);
  return await requestApi("/erp/query/" + id);
}

// ===== 批量查询（必须登录）=====
async function queryItems(ids) {
  const uniqueIds = [...new Set((ids || []).map(i => String(i).trim()).filter(Boolean))];
  if (!uniqueIds.length) return { success: false, error: "ids 为空" };
  const stored = await chrome.storage.local.get("erp_token");
  if (!stored.erp_token) {
    return { success: false, error: "请先在插件浮窗中登录 ERP 账号" };
  }
  console.log("[queryItems] /erp/full/batch，数量:", uniqueIds.length);
  return await requestApi("/erp/full/batch", {
    method: "POST",
    body: JSON.stringify({ ids: uniqueIds })
  });
}

// ===== 获取仓库列表 =====
async function getWarehouses() {
  const stored = await chrome.storage.local.get("erp_token");
  if (!stored.erp_token) return { success: false, error: "请先登录 ERP 账号" };
  return await requestApi("/erp/warehouses");
}

// ===== 获取水印配置 =====
async function getWatermarks() {
  const stored = await chrome.storage.local.get("erp_token");
  if (!stored.erp_token) return { success: false, error: "请先登录 ERP 账号" };
  return await requestApi("/user/watermark");
}

// ===== 登录 =====
async function erpLogin(username, password) {
  try {
    const res = await fetch(API_URL + "/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (data.code === 0 && data.data?.token) {
      await chrome.storage.local.set({ erp_token: data.data.token, erp_user: data.data.user });
      console.log("✅ [Background] 登录成功");
      return { success: true, data: data.data };
    }
    return { success: false, error: data.msg || "登录失败" };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

// ===== 登出 =====
async function erpLogout() {
  await chrome.storage.local.remove(["erp_token", "erp_user"]);
  console.log("✅ [Background] 已登出");
  return { success: true };
}

// ===== 获取当前用户 =====
async function getCurrentUser() {
  const stored = await chrome.storage.local.get(["erp_token", "erp_user"]);
  if (!stored.erp_token) return { success: true, user: null };
  return { success: true, user: stored.erp_user || null, token: stored.erp_token };
}

// ===== 延迟库存调度 =====
async function scheduleStockTask(task) {
  const alarmName = "stock_" + Date.now() + "_" + task.product_id;
  const storageKey = "stockTask:" + alarmName;
  await chrome.storage.local.set({ [storageKey]: task });
  await chrome.alarms.create(alarmName, { delayInMinutes: task.delay_minutes });
  console.log("⏰ [库存] 延迟任务已创建:", alarmName, "将在", task.delay_minutes, "分钟后执行");
  return alarmName;
}

// ===== 一键跟卖 =====
async function followSell(msg) {
  console.log("[跟卖] 开始 SKU:", msg.sku, "price:", msg.price);
  try {
    const stored = await chrome.storage.local.get("erp_token");
    if (!stored.erp_token) return { success: false, error: "请先登录 ERP 账号才能跟卖" };

    // Step 1：获取图片
    console.log("[跟卖] Step 1: 获取竞品图片...");
    const images = await getProductImages(msg.sku);
    console.log("[跟卖] 获取到图片:", images.length, "张");

    // Step 2：获取水印配置并处理图片
    let processedImages = images;
    if (images.length > 0 && msg.enableWatermark !== false) {
      console.log("[跟卖] Step 2: 获取水印配置...");
      const wmResult = await requestApi("/user/watermark");
      let wmConfig = null;
      if (wmResult?.success && wmResult.data?.code === 0) {
        const wms = wmResult.data.data.watermarks || [];
        if (msg.watermarkIndex >= 0 && wms[msg.watermarkIndex]) {
          wmConfig = wms[msg.watermarkIndex];
          console.log("[跟卖] 使用水印:", wmConfig.name);
        } else if (wms.length > 0) {
          wmConfig = wms[0];
          console.log("[跟卖] 使用默认水印:", wmConfig.name);
        }
      }
      console.log("[跟卖] Step 2.5: 处理图片...");
      processedImages = await addWatermarkToImages(images, wmConfig);
      console.log("[跟卖] 处理完成:", processedImages.length, "张");
    }

    // Step 3：调用 Worker
    console.log("[跟卖] Step 3: 调用 /erp/follow-sell");
    const importResult = await requestApi("/erp/follow-sell", {
      method: "POST",
      body: JSON.stringify({
        sku: msg.sku, price: msg.price, name: msg.name || "",
        quantity: msg.quantity || null,
        warehouse_id: msg.warehouse_id || null,
        stock_delay: msg.stock_delay || 0,
        images: processedImages
      })
    });

    console.log("[跟卖] 返回:", JSON.stringify(importResult).slice(0, 300));
    if (!importResult.success) {
      return { success: false, status: importResult.status || 500, error: importResult.error || "跟卖失败" };
    }

    const apiData = importResult.data;

    if (apiData?.code === 202) {
      return {
        success: true, status: 202,
        data: { code: 202, msg: "商品创建中", data: { task_id: apiData?.data?.task_id, offer_id: apiData?.data?.offer_id, sku: msg.sku, imageCount: processedImages.length, status: "processing" } }
      };
    }

    if (apiData?.code === 0) {
      const info = apiData.data || {};
      // 处理延迟库存
      if (info.stockDelayed && info.pendingStock) {
        await scheduleStockTask(info.pendingStock);
      }
      return {
        success: true, status: 200,
        data: {
          code: 0, msg: "跟卖成功",
          data: {
            product_id: info.product_id, offer_id: info.offer_id,
            sku: msg.sku, price: msg.price,
            imageCount: processedImages.length,
            imageUploaded: info.imageUploaded, uploadedCount: info.uploadedCount,
            stockSet: info.stockSet, stockDelayed: info.stockDelayed || false,
            delayMinutes: info.pendingStock ? info.pendingStock.delay_minutes : 0,
            status: "completed"
          }
        }
      };
    }

    return { success: false, status: 500, error: apiData?.msg || "跟卖失败" };
  } catch (e) {
    console.error("[跟卖] 异常:", e.message);
    return { success: false, status: 500, error: e.message };
  }
}

// ===== 延迟库存执行 =====
chrome.alarms.onAlarm.addListener(async function(alarm) {
  if (!alarm.name || !alarm.name.startsWith("stock_")) return;
  const storageKey = "stockTask:" + alarm.name;
  const stored = await chrome.storage.local.get(storageKey);
  const task = stored[storageKey];
  if (!task) { console.warn("⚠️ [库存] 未找到任务:", alarm.name); return; }
  console.log("⏰ [库存] 开始执行延迟任务:", task);
  try {
    const result = await requestApi("/erp/set-stock", {
      method: "POST",
      body: JSON.stringify({ product_id: task.product_id, quantity: task.quantity, warehouse_id: task.warehouse_id })
    });
    if (result?.success && result.data?.code === 0) {
      console.log("✅ [库存] 延迟库存设置成功:", task.product_id);
    } else {
      console.error("❌ [库存] 延迟库存设置失败:", result?.error || result?.data?.msg);
    }
  } catch (e) {
    console.error("❌ [库存] 延迟库存异常:", e.message);
  }
  await chrome.storage.local.remove(storageKey);
});

// ===== Chrome Message Handler =====
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  console.log("📨 [Background] 收到消息:", msg.action);
  (async function() {
    try {
      if (msg.action === "querySingle")    return await querySingle(msg.id);
      if (msg.action === "queryItems")     return await queryItems(msg.ids);
      if (msg.action === "getWarehouses")  return await getWarehouses();
      if (msg.action === "getWatermarks")  return await getWatermarks();
      if (msg.action === "followSell")     return await followSell(msg);
      if (msg.action === "toggleFloating") return { success: true };
      if (msg.action === "erpLogin")       return await erpLogin(msg.username, msg.password);
      if (msg.action === "erpLogout")      return await erpLogout();
      if (msg.action === "getUser")        return await getCurrentUser();
      return { success: false, error: "未知 action" };
    } catch (e) {
      return { success: false, error: e.message };
    }
  })().then(function(result) {
    console.log("📤 [Background] 返回:", result);
    sendResponse(result);
  });
  return true;
});

// ===== 点击插件图标 =====
chrome.action.onClicked.addListener(function(tab) {
  chrome.tabs.sendMessage(tab.id, { action: "toggleFloating" }, function() {
    if (chrome.runtime.lastError) console.log("❌ 发送失败:", chrome.runtime.lastError.message);
  });
});
console.log("✅ [ERP] Ozon ERP 插件已加载");

(function () {
  if (document.getElementById("ozon-erp-floating")) {
    console.log("⚠️ [ERP] 已存在，跳过");
    return;
  }

  var allData = [];
  var favorites = [];
  var lastSingleItem = null;
  var lastUrl = location.href;
  var lastAutoLoadedProductId = null;

  var ERP_LIST_CONCURRENCY = 5;
  var erpListInjecting = false;
  var erpListInjectTimer = null;
  var erpListNeedRerun = false;
  var warehouseLoaded = false;
  var erpListItemCache = new Map();

  // ✅ IntersectionObserver 懒加载
  var cardObserver = null;
  var pendingCards = new Map(); // sku → { card, container }

  // ===== 样式注入 =====
  var style = document.createElement("style");
  style.textContent = "#ozon-erp-floating{position:fixed;top:80px;right:20px;width:380px;max-height:80vh;background:#fff;border:1px solid #d9d9d9;border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,0.15);z-index:999999;font-family:Arial,sans-serif;display:none;overflow:hidden;flex-direction:column}#ozon-erp-floating.show{display:flex}#ozon-erp-mini{position:fixed;right:20px;bottom:24px;width:48px;height:48px;border-radius:50%;background:#1677ff;color:#fff;display:none;align-items:center;justify-content:center;font-size:22px;cursor:pointer;z-index:999999;box-shadow:0 8px 20px rgba(22,119,255,.35)}#ozon-erp-mini.show{display:flex}.erp-header{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:#1677ff;color:#fff;cursor:move;user-select:none;flex-shrink:0}.erp-title{font-weight:bold;font-size:14px}.erp-controls{display:flex;gap:10px;align-items:center}.erp-btn-ctrl{cursor:pointer;font-size:16px;line-height:1}.erp-tabs{display:flex;border-bottom:1px solid #f0f0f0;background:#fafafa;flex-shrink:0}.erp-tab{flex:1;text-align:center;padding:10px 4px;cursor:pointer;font-size:11px;color:#666;border-bottom:2px solid transparent}.erp-tab.active{color:#1677ff;font-weight:bold;border-bottom-color:#1677ff;background:#fff}.erp-body{padding:12px;overflow-y:auto;flex:1}.erp-panel{display:none}.erp-panel.active{display:block}.erp-panel label{display:block;margin:10px 0 6px;font-size:12px;color:#333;font-weight:600}.erp-panel input,.erp-panel textarea,.erp-panel select{width:100%;box-sizing:border-box;border:1px solid #d9d9d9;border-radius:6px;padding:8px 10px;font-size:12px;outline:none;background:#fff}.erp-panel textarea{min-height:110px;resize:vertical}.erp-btn-row{display:flex;gap:8px;margin-top:12px;flex-wrap:wrap}.erp-btn{border:none;border-radius:6px;padding:9px 12px;cursor:pointer;font-size:12px;font-weight:bold}.btn-primary{background:#1677ff;color:#fff}.btn-default{background:#f5f5f5;color:#333}.btn-success{background:#52c41a;color:#fff}.btn-danger{background:#ff4d4f;color:#fff}.erp-status{margin-top:10px;font-size:12px;color:#555;line-height:1.5;word-break:break-all}.erp-table-wrap{overflow:auto;margin-top:10px;border:1px solid #f0f0f0;border-radius:8px}.erp-table-wrap table{width:100%;border-collapse:collapse;font-size:12px}.erp-table-wrap th,.erp-table-wrap td{border-bottom:1px solid #f0f0f0;padding:8px;text-align:left;white-space:nowrap}.erp-table-wrap th{background:#fafafa;position:sticky;top:0;z-index:1}.empty-state{text-align:center;padding:24px 10px;color:#999}.empty-icon{font-size:28px;margin-bottom:8px}.null-val{color:#bbb}";
  document.head.appendChild(style);

  // ===== UI 结构 =====
  var container = document.createElement("div");
  container.id = "ozon-erp-floating";
  container.innerHTML = `
    <div class="erp-header">
      <div class="erp-title">🔍 Ozon ERP 选品助手</div>
      <div class="erp-controls">
        <span class="erp-btn-ctrl" id="erp-minimize" title="最小化">—</span>
        <span class="erp-btn-ctrl" id="erp-close" title="关闭">✕</span>
      </div>
    </div>

    <!-- 登录栏 -->
    <div id="erp-login-bar" style="background:#fffbe6;border-bottom:1px solid #ffe58f;padding:10px 14px;font-size:12px;flex-shrink:0;">
      <div id="erp-login-form">
        <div style="color:#ad6800;margin-bottom:8px;font-weight:bold;">⚠️ 请登录 ERP 账号</div>
        <div style="display:flex;gap:6px;align-items:center;">
          <input id="erp-login-user" type="text" placeholder="用户名"
            style="flex:1;padding:6px 8px;border:1px solid #d9d9d9;border-radius:4px;font-size:12px;outline:none;background:#fff;" />
          <input id="erp-login-pass" type="password" placeholder="密码"
            style="flex:1;padding:6px 8px;border:1px solid #d9d9d9;border-radius:4px;font-size:12px;outline:none;background:#fff;" />
          <button id="erp-login-btn"
            style="background:#1677ff;color:#fff;border:none;border-radius:4px;padding:6px 12px;cursor:pointer;font-size:12px;font-weight:bold;white-space:nowrap;">
            登录
          </button>
        </div>
        <div id="erp-login-tip" style="margin-top:6px;color:#999;font-size:11px;">
          登录后可使用你自己的 Ozon 密钥跟卖
        </div>
      </div>
      <div id="erp-login-info" style="display:none;">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <span style="color:#389e0d;font-weight:bold;">
            ✅ 已登录：<span id="erp-logged-username">-</span>
          </span>
          <button id="erp-logout-btn"
            style="background:none;border:1px solid #d9d9d9;border-radius:4px;padding:3px 8px;cursor:pointer;font-size:11px;color:#666;">
            退出
          </button>
        </div>
      </div>
    </div>

    <div class="erp-tabs">
      <div class="erp-tab active" data-tab="query">🔍 竞品查询</div>
      <div class="erp-tab" data-tab="batch">📦 批量分析</div>
      <div class="erp-tab" data-tab="follow">🛍️ 快速跟卖</div>
      <div class="erp-tab" data-tab="favorites">⭐ 我的收藏</div>
    </div>

    <div class="erp-body">

      <!-- 竞品查询 -->
      <div class="erp-panel active" id="panel-query">
        <label>商品 ID</label>
        <input type="text" id="erp-single-id" placeholder="例如：3617702478" />
        <div class="erp-btn-row">
          <button class="erp-btn btn-primary" id="erp-query-single">🔍 查询</button>
          <button class="erp-btn btn-default" id="erp-use-current">📌 用当前页面 ID</button>
        </div>
        <div class="erp-status" id="erp-single-status"></div>
        <div id="erp-single-result"></div>
      </div>

      <!-- 批量分析 -->
      <div class="erp-panel" id="panel-batch">
        <label>批量商品 ID（每行一个，最多 50 个）</label>
        <textarea id="erp-batch-ids" placeholder="例如：&#10;3617702478&#10;2478285376"></textarea>
        <div class="erp-btn-row">
          <button class="erp-btn btn-primary" id="erp-query-batch">🚀 批量查询</button>
          <button class="erp-btn btn-success" id="erp-export-csv" style="display:none;">📥 导出 CSV</button>
          <button class="erp-btn btn-danger" id="erp-clear-batch">🗑️ 清空</button>
        </div>
        <div class="erp-status" id="erp-batch-status"></div>
        <div id="erp-batch-result"></div>
      </div>

      <!-- 快速跟卖 -->
      <div class="erp-panel" id="panel-follow">
        <div style="background:#e6f7ff;border-radius:6px;padding:10px;margin-bottom:12px;font-size:12px;color:#0050b3;">
          ℹ️ 通过 SKU 直接复制竞品商品（包括图片）到你的店铺
        </div>
        <div id="followProductInfo" style="background:#f5f5f5;border-radius:6px;padding:10px;margin-bottom:12px;font-size:12px;display:none;">
          <div><b>SKU:</b> <span id="followSkuShow">-</span></div>
          <div style="margin-top:4px;"><b>名称:</b> <span id="followNameShow">-</span></div>
        </div>
        <label>商品 SKU</label>
        <input type="number" id="followSkuInput" placeholder="例如：2034937231" />
        <label>商品名称（选填）</label>
        <input type="text" id="followNameInput" placeholder="留空则自动用竞品名称" />
        <label>价格（卢布）</label>
        <input type="number" id="followPrice" placeholder="例如：2000" />
        <label>仓库</label>
        <select id="followWarehouse">
          <option value="">-- 选择仓库（自动加载）--</option>
        </select>
        <div style="margin-top:6px;display:flex;gap:6px;align-items:center;">
          <input type="text" id="followWarehouseManual" placeholder="或手动输入仓库 ID" style="flex:1;" />
          <button class="erp-btn btn-default" style="padding:4px 8px;font-size:11px;white-space:nowrap;" id="erp-reload-warehouses">🔄 重新加载</button>
        </div>
        <div style="font-size:11px;color:#999;margin-top:4px;">仓库 ID 可在 seller.ozon.ru → 仓库管理 中查看</div>
        <label>库存数量（不填则不设置库存）</label>
        <input type="number" id="followQuantity" placeholder="例如：100" />
        <label>库存添加时间</label>
        <select id="followStockDelay">
          <option value="0">立即添加库存</option>
          <option value="5">5 分钟后添加</option>
          <option value="10">10 分钟后添加</option>
          <option value="15">15 分钟后添加</option>
          <option value="30">30 分钟后添加</option>
          <option value="60">1 小时后添加</option>
          <option value="120">2 小时后添加</option>
          <option value="180">3 小时后添加</option>
        </select>
        <div style="font-size:11px;color:#999;margin-top:4px;">延迟添加可让商品先完成审核再上架</div>
        <label>水印选择</label>
        <div style="display:flex;gap:6px;align-items:center;">
          <input type="checkbox" id="enableWatermark" checked style="width:auto;" />
          <label style="margin:0;font-weight:normal;color:#666;font-size:12px;">启用水印（防复制禁令）</label>
        </div>
        <select id="watermarkSelect" style="margin-top:6px;">
          <option value="">-- 加载中 --</option>
        </select>
        <div class="erp-btn-row">
          <button class="erp-btn btn-primary" id="erp-follow-submit">🛍️ 一键跟卖</button>
          <button class="erp-btn btn-default" id="erp-follow-current">📌 用当前商品</button>
        </div>
        <div class="erp-status" id="erp-follow-status"></div>
      </div>

      <!-- 我的收藏 -->
      <div class="erp-panel" id="panel-favorites">
        <div class="erp-btn-row">
          <button class="erp-btn btn-primary" id="erp-refresh-favorites">🔄 刷新数据</button>
          <button class="erp-btn btn-success" id="erp-export-favorites">📥 导出 CSV</button>
          <button class="erp-btn btn-danger" id="erp-clear-favorites">🗑️ 清空</button>
        </div>
        <div class="erp-status" id="erp-favorites-status"></div>
        <div id="erp-favorites-result"></div>
      </div>

    </div>
  `;
  document.body.appendChild(container);

  var miniBtn = document.createElement("div");
  miniBtn.id = "ozon-erp-mini";
  miniBtn.innerHTML = "🔍";
  miniBtn.title = "打开 Ozon ERP";
  document.body.appendChild(miniBtn);

  // ===== 工具函数 =====
  function setStatus(id, msg, type) {
    var el = document.getElementById(id);
    if (!el) return;
    el.innerHTML = type === "err"
      ? '<span style="color:#ff4d4f">' + msg + "</span>"
      : msg;
  }

  function escapeHtml(str) {
    return String(str || "")
      .replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  function saveFavorites() { chrome.storage.local.set({ erp_favorites: favorites }); }

  function isFavorited(itemId) {
    return favorites.some(function(f) { return String(f.itemId) === String(itemId); });
  }

  function extractIdFromUrl(url) {
    var match = String(url || "").match(
      /\/product\/.*?-(\d{7,15})(?:\/|\?|$)|\/product\/(\d{7,15})(?:\/|\?|$)/
    );
    return match ? match[1] || match[2] : null;
  }

  function hasValidItemData(item) {
    if (!item) return false;
    var fields = [item.skuName, item.catNamePath, item.photo, item.brand,
      item.monthSales, item.monthGmvRmb, item.avgPriceRmb,
      item.sessionCount, item.clickRatio, item.convToCartPdp,
      item.weight, item.dimensionsLength, item.logDate];
    for (var i = 0; i < fields.length; i++) {
      if (fields[i] !== null && fields[i] !== undefined && fields[i] !== "") return true;
    }
    return false;
  }

  function isOzonProductPage() { return /\/product\//.test(location.pathname); }

  function isOzonListPage() {
    if (isOzonProductPage()) return false;
    var p = location.pathname || "";
    if (p.includes("/search") || p.includes("/category") || p.includes("/seller")) return true;
    return document.querySelectorAll('.tile-root a[href*="/product/"]').length >= 4;
  }

  function getItemById(itemId) {
    var id = String(itemId);
    if (lastSingleItem && String(lastSingleItem.itemId) === id) return lastSingleItem;
    var inBatch = allData.find(function(i) { return String(i.itemId) === id; });
    if (inBatch) return inBatch;
    return favorites.find(function(i) { return String(i.itemId) === id; }) || null;
  }

  function updateFavoriteButtons(itemId) {
    var fav = isFavorited(itemId);
    document.querySelectorAll('[data-fav-id="' + itemId + '"]').forEach(function(btn) {
      btn.textContent = fav ? "⭐" : "☆";
    });
  }

  function toggleFavoriteById(itemId) {
    var item = getItemById(itemId);
    if (!item) return;
    var idx = favorites.findIndex(function(f) { return String(f.itemId) === String(itemId); });
    if (idx === -1) { favorites.push(item); setStatus("erp-single-status", "⭐ 已收藏 " + itemId); }
    else { favorites.splice(idx, 1); setStatus("erp-single-status", "✅ 已取消收藏 " + itemId); }
    saveFavorites();
    updateFavoriteButtons(itemId);
    var favPanel = document.getElementById("panel-favorites");
    if (favPanel && favPanel.classList.contains("active")) renderFavorites();
  }

  function bindFavoriteButtons(scope) {
    scope = scope || document;
    scope.querySelectorAll("[data-fav-id]").forEach(function(btn) {
      if (btn.dataset.bound === "1") return;
      btn.dataset.bound = "1";
      btn.addEventListener("click", function() { toggleFavoriteById(btn.getAttribute("data-fav-id")); });
    });
  }

  function exportCSV(data, filename) {
    if (!data || !data.length) return;
    var cols = [
      { key: "itemId", label: "商品 ID" }, { key: "skuName", label: "名称" },
      { key: "catNamePath", label: "类目" }, { key: "monthSales", label: "月销量" },
      { key: "monthGmvRmb", label: "月销额¥" }, { key: "avgPriceRmb", label: "均价¥" },
      { key: "sessionCount", label: "访客数" }, { key: "clickRatio", label: "点击率%" },
      { key: "convToCartPdp", label: "加购率" }, { key: "weight", label: "重量 kg" },
      { key: "dimensionsLength", label: "长 cm" }, { key: "dimensionsWidth", label: "宽 cm" },
      { key: "dimensionsHeight", label: "高 cm" }, { key: "volume", label: "体积 L" },
      { key: "sources", label: "发货" }, { key: "logDate", label: "日期" }
    ];
    var csv = "\uFEFF" + cols.map(function(c) { return c.label; }).join(",") + "\n";
    data.forEach(function(item) {
      csv += cols.map(function(c) {
        return '"' + (item[c.key] !== null && item[c.key] !== undefined ? item[c.key] : "") + '"';
      }).join(",") + "\n";
    });
    var blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = filename + "_" + new Date().toISOString().slice(0, 10) + ".csv";
    a.click();
    URL.revokeObjectURL(a.href);
  }

  function switchToFollowTab() {
    container.querySelectorAll(".erp-tab").forEach(function(t) { t.classList.remove("active"); });
    container.querySelectorAll(".erp-panel").forEach(function(p) { p.classList.remove("active"); });
    var followTab = container.querySelector('.erp-tab[data-tab="follow"]');
    var followPanel = document.getElementById("panel-follow");
    if (followTab) followTab.classList.add("active");
    if (followPanel) followPanel.classList.add("active");
    container.classList.add("show");
    miniBtn.classList.remove("show");
    if (!warehouseLoaded) loadWarehouses();
  }

  function handleSingleQueryResult(response, id, isAuto) {
    var resultEl = document.getElementById("erp-single-result");
    if (!response || !response.success) {
      if (resultEl) resultEl.innerHTML = "";
      setStatus("erp-single-status", "❌ 查询失败：" + (response?.error || "未知错误"), "err");
      return false;
    }
    var data = response.data;
    if (!data || data.code !== 0 || !data.data || !hasValidItemData(data.data)) {
      if (resultEl) resultEl.innerHTML = "";
      setStatus("erp-single-status", "❌ " + (data?.msg || "商品未收录或数据为空"), "err");
      return false;
    }
    document.getElementById("erp-single-id").value = id;
    renderSingleResult(data.data);
    setStatus("erp-single-status", isAuto ? "✅ 已自动加载：" + id : "✅ 查询成功");
    return true;
  }

  function renderSingleResult(item) {
    var result = document.getElementById("erp-single-result");
    if (!result) return;
    lastSingleItem = item;
    result.innerHTML =
      '<div style="background:#fff;border:2px solid #1677ff;border-radius:12px;padding:16px;margin-top:12px;">' +
      '<div style="display:flex;justify-content:space-between;margin-bottom:12px;">' +
      '<div style="font-size:15px;font-weight:bold;color:#1677ff;">📊 商品数据</div>' +
      '<span data-fav-id="' + item.itemId + '" style="cursor:pointer;font-size:18px;">' + (isFavorited(item.itemId) ? "⭐" : "☆") + "</span>" +
      "</div>" +
      "<div style='margin-bottom:6px;'><b>ID：</b>" + (item.itemId || "-") + "</div>" +
      "<div style='margin-bottom:6px;'><b>名称：</b>" + escapeHtml(item.skuName || "-") + "</div>" +
      "<div style='margin-bottom:6px;'><b>类目：</b>" + escapeHtml(item.catNamePath || "-") + "</div>" +
      "<div style='margin-bottom:6px;'><b>月销量：</b>" + (item.monthSales || "-") + " 件</div>" +
      "<div style='margin-bottom:6px;'><b>月销额：</b>¥" + (item.monthGmvRmb || "-") + "</div>" +
      "<div style='margin-bottom:6px;'><b>均价：</b>¥" + (item.avgPriceRmb || "-") + "</div>" +
      "<div style='margin-bottom:6px;'><b>访客数：</b>" + (item.sessionCount || "-") + "</div>" +
      "<div style='margin-bottom:6px;'><b>点击率：</b>" + (item.clickRatio || "-") + "%</div>" +
      "<div style='margin-bottom:6px;'><b>加购率：</b>" + (item.convToCartPdp || "-") + "</div>" +
      "<div style='margin-bottom:6px;'><b>月销增长：</b>" + (item.monthSalesRatio || "-") + "%</div>" +
      "<div style='margin-bottom:6px;'><b>广告占比：</b>" + (item.drr || "-") + "%</div>" +
      "<div style='margin-bottom:6px;'><b>发货：</b>" + (item.sources || "-") + "</div>" +
      "<div style='margin-bottom:6px;'><b>重量：</b>" + (item.weight || "-") + " kg</div>" +
      "<div style='margin-bottom:6px;'><b>体积：</b>" + (item.volume || "-") + " L</div>" +
      "<div style='margin-bottom:6px;'><b>尺寸：</b>" + (item.dimensionsLength || "-") + " × " + (item.dimensionsWidth || "-") + " × " + (item.dimensionsHeight || "-") + " cm</div>" +
      "<div style='margin-bottom:6px;'><b>FBO 佣金：</b>" + (item.fboCommissionRate ? (item.fboCommissionRate * 100).toFixed(2) : "-") + "%</div>" +
      "<div style='margin-bottom:6px;'><b>FBS 佣金：</b>" + (item.fbsCommissionRate ? (item.fbsCommissionRate * 100).toFixed(2) : "-") + "%</div>" +
      "<div style='margin-bottom:6px;'><b>数据日期：</b>" + (item.logDate || "-") + "</div>" +
      "</div>";
    bindFavoriteButtons(result);
  }

  function renderBatchResult(items, targetId) {
    var result = document.getElementById(targetId);
    if (!result) return;
    if (!items || !items.length) {
      result.innerHTML = '<div class="empty-state"><div class="empty-icon">📭</div><p>没有数据</p></div>';
      return;
    }
    var cols = [
      { key: "itemId", label: "商品 ID" }, { key: "skuName", label: "名称" },
      { key: "catNamePath", label: "类目" }, { key: "monthSales", label: "月销量" },
      { key: "monthGmvRmb", label: "月销额¥" }, { key: "avgPriceRmb", label: "均价¥" },
      { key: "sessionCount", label: "访客" }, { key: "clickRatio", label: "点击率%" },
      { key: "convToCartPdp", label: "加购率" }, { key: "weight", label: "重量 kg" },
      { key: "sources", label: "发货" }, { key: "logDate", label: "日期" }
    ];
    var html = '<div class="erp-table-wrap"><table><tr><th>⭐</th>';
    cols.forEach(function(c) { html += "<th>" + c.label + "</th>"; });
    html += "</tr>";
    items.forEach(function(item) {
      html += '<tr><td><span data-fav-id="' + item.itemId + '" style="cursor:pointer;font-size:16px;">' + (isFavorited(item.itemId) ? "⭐" : "☆") + "</span></td>";
      cols.forEach(function(c) {
        var val = item[c.key];
        html += "<td>" + (val !== null && val !== undefined && val !== "" ? escapeHtml(String(val)) : '<span class="null-val">-</span>') + "</td>";
      });
      html += "</tr>";
    });
    html += "</table></div>";
    result.innerHTML = html;
    bindFavoriteButtons(result);
  }

  function renderFavorites() {
    if (!favorites || !favorites.length) {
      document.getElementById("erp-favorites-result").innerHTML =
        '<div class="empty-state"><div class="empty-icon">⭐</div><p>还没有收藏商品</p></div>';
      return;
    }
    renderBatchResult(favorites, "erp-favorites-result");
    setStatus("erp-favorites-status", "共 " + favorites.length + " 个");
  }

  // ===== 仓库加载 =====
  async function loadWarehouses() {
    var select = document.getElementById("followWarehouse");
    if (!select || select.dataset.loading === "1") return;
    select.dataset.loading = "1";
    setStatus("erp-follow-status", "⏳ 正在加载仓库列表...");
    try {
      var res = await new Promise(function(resolve) {
        chrome.runtime.sendMessage({ action: "getWarehouses" }, resolve);
      });
      console.log("🏭 [loadWarehouses] 返回:", JSON.stringify(res).slice(0, 300));
      var warehouses = null;
      if (res && res.success) {
        var inner = res.data;
        if (inner && inner.code === 0 && Array.isArray(inner.data) && inner.data.length > 0) {
          warehouses = inner.data;
        } else if (inner && Array.isArray(inner.result) && inner.result.length > 0) {
          warehouses = inner.result;
        }
      }
      if (warehouses && warehouses.length > 0) {
        while (select.options.length > 1) select.remove(1);
        warehouses.forEach(function(w) {
          var option = document.createElement("option");
          option.value = w.warehouse_id;
          option.textContent = w.name + "（" + (w.type || "") + "）（ID: " + w.warehouse_id + "）";
          select.appendChild(option);
        });
        warehouseLoaded = true;
        setStatus("erp-follow-status", "✅ 已加载 " + warehouses.length + " 个仓库");
        if (warehouses.length === 1) {
          select.value = warehouses[0].warehouse_id;
        }
      } else {
        setStatus("erp-follow-status", "⚠️ 未获取到仓库，可手动输入仓库 ID");
      }
    } catch (e) {
      setStatus("erp-follow-status", "❌ 仓库加载异常: " + e.message, "err");
    } finally {
      select.dataset.loading = "0";
    }
  }

  // ===== 水印列表加载 =====
  async function loadWatermarkList() {
    var select = document.getElementById("watermarkSelect");
    if (!select) return;
    try {
      var res = await new Promise(function(resolve) {
        chrome.runtime.sendMessage({ action: "getWatermarks" }, resolve);
      });
      if (res && res.success && res.data && res.data.code === 0) {
        var wms = res.data.data.watermarks || [];
        select.innerHTML = "";
        if (wms.length === 0) {
          select.innerHTML = '<option value="">暂无水印，请到管理后台配置</option>';
        } else {
          wms.forEach(function(wm, idx) {
            var option = document.createElement("option");
            option.value = idx;
            option.textContent = wm.name || ("水印 " + (idx + 1));
            select.appendChild(option);
          });
        }
      } else {
        select.innerHTML = '<option value="">加载失败</option>';
      }
    } catch (e) {
      select.innerHTML = '<option value="">加载异常</option>';
    }
  }

  // ===== 登录逻辑 =====
  function showLoggedIn(user) {
    var loginForm = document.getElementById("erp-login-form");
    var loginInfo = document.getElementById("erp-login-info");
    var loggedName = document.getElementById("erp-logged-username");
    if (loginForm) loginForm.style.display = "none";
    if (loginInfo) loginInfo.style.display = "block";
    if (loggedName) loggedName.textContent = user.username || "-";
  }

  function showLoggedOut() {
    var loginForm = document.getElementById("erp-login-form");
    var loginInfo = document.getElementById("erp-login-info");
    if (loginForm) loginForm.style.display = "block";
    if (loginInfo) loginInfo.style.display = "none";
  }

  document.getElementById("erp-login-btn").addEventListener("click", function() {
    var username = document.getElementById("erp-login-user").value.trim();
    var password = document.getElementById("erp-login-pass").value.trim();
    var tip = document.getElementById("erp-login-tip");
    var btn = document.getElementById("erp-login-btn");
    if (!username || !password) { tip.style.color = "#ff4d4f"; tip.textContent = "请填写用户名和密码"; return; }
    btn.disabled = true; btn.textContent = "登录中...";
    tip.style.color = "#999"; tip.textContent = "登录中...";
    chrome.runtime.sendMessage({ action: "erpLogin", username: username, password: password }, function(res) {
      btn.disabled = false; btn.textContent = "登录";
      if (res && res.success) {
        tip.style.color = "#52c41a"; tip.textContent = "✅ 登录成功";
        showLoggedIn(res.data.user);
        warehouseLoaded = false;
        var sel = document.getElementById("followWarehouse");
        if (sel) { while (sel.options.length > 1) sel.remove(1); sel.dataset.loading = "0"; }
        var fp = document.getElementById("panel-follow");
        if (fp && fp.classList.contains("active")) loadWarehouses();
        loadWatermarkList();
      } else {
        tip.style.color = "#ff4d4f"; tip.textContent = "❌ " + (res?.error || "登录失败");
      }
    });
  });

  document.getElementById("erp-logout-btn").addEventListener("click", function() {
    chrome.runtime.sendMessage({ action: "erpLogout" }, function() {
      showLoggedOut(); warehouseLoaded = false;
      var sel = document.getElementById("followWarehouse");
      if (sel) { while (sel.options.length > 1) sel.remove(1); sel.dataset.loading = "0"; }
    });
  });

  // ===== Tab 切换 =====
  container.querySelectorAll(".erp-tab").forEach(function(tab) {
    tab.addEventListener("click", function() {
      container.querySelectorAll(".erp-tab").forEach(function(t) { t.classList.remove("active"); });
      container.querySelectorAll(".erp-panel").forEach(function(p) { p.classList.remove("active"); });
      tab.classList.add("active");
      var panel = document.getElementById("panel-" + tab.dataset.tab);
      if (panel) panel.classList.add("active");
      if (tab.dataset.tab === "favorites") renderFavorites();
      if (tab.dataset.tab === "follow") {
        if (!warehouseLoaded) loadWarehouses();
        loadWatermarkList();
        bindReloadWarehouseBtn();
      }
    });
  });

  function bindReloadWarehouseBtn() {
    var reloadBtn = document.getElementById("erp-reload-warehouses");
    if (!reloadBtn || reloadBtn.dataset.bound === "1") return;
    reloadBtn.dataset.bound = "1";
    reloadBtn.addEventListener("click", function() {
      warehouseLoaded = false;
      var sel = document.getElementById("followWarehouse");
      if (sel) { while (sel.options.length > 1) sel.remove(1); sel.dataset.loading = "0"; }
      loadWarehouses();
    });
  }

  // ===== 关闭/最小化 =====
  document.getElementById("erp-close").addEventListener("click", function() {
    container.classList.remove("show"); miniBtn.classList.add("show");
  });
  document.getElementById("erp-minimize").addEventListener("click", function() {
    container.classList.remove("show"); miniBtn.classList.add("show");
  });
  miniBtn.addEventListener("click", function() {
    miniBtn.classList.remove("show"); container.classList.add("show");
  });

  // ===== 消息监听 =====
  chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
    if (msg.action === "toggleFloating") {
      if (container.classList.contains("show")) {
        container.classList.remove("show"); miniBtn.classList.add("show");
      } else {
        container.classList.add("show"); miniBtn.classList.remove("show");
      }
      sendResponse({ success: true });
    }
    return true;
  });

  // ===== 拖拽 =====
  var header = container.querySelector(".erp-header");
  var isDragging = false, startX = 0, startY = 0, startLeft = 0, startTop = 0;
  header.addEventListener("mousedown", function(e) {
    if (e.target.classList.contains("erp-btn-ctrl")) return;
    isDragging = true;
    var rect = container.getBoundingClientRect();
    startX = e.clientX; startY = e.clientY; startLeft = rect.left; startTop = rect.top;
    document.body.style.userSelect = "none";
  });
  document.addEventListener("mousemove", function(e) {
    if (!isDragging) return;
    container.style.left = (startLeft + e.clientX - startX) + "px";
    container.style.top = (startTop + e.clientY - startY) + "px";
    container.style.right = "auto";
  });
  document.addEventListener("mouseup", function() {
    isDragging = false; document.body.style.userSelect = "";
  });

  // ===== 竞品查询 =====
  document.getElementById("erp-query-single").addEventListener("click", function() {
    var id = document.getElementById("erp-single-id").value.trim();
    if (!id) { setStatus("erp-single-status", "❌ 请输入商品 ID", "err"); return; }
    container.classList.add("show"); miniBtn.classList.remove("show");
    setStatus("erp-single-status", "⏳ 查询中...");
    document.getElementById("erp-single-result").innerHTML = "";
    chrome.runtime.sendMessage({ action: "querySingle", id }, function(response) {
      handleSingleQueryResult(response, id, false);
    });
  });

  document.getElementById("erp-use-current").addEventListener("click", function() {
    var id = extractIdFromUrl(location.href);
    if (id) { document.getElementById("erp-single-id").value = id; setStatus("erp-single-status", "✅ 已获取当前页面 ID：" + id); }
    else { setStatus("erp-single-status", "❌ 当前页面不是 Ozon 商品页", "err"); }
  });

  // ===== 批量查询 =====
  document.getElementById("erp-query-batch").addEventListener("click", function() {
    var idsInput = document.getElementById("erp-batch-ids").value.trim();
    if (!idsInput) { setStatus("erp-batch-status", "❌ 请输入商品 ID", "err"); return; }
    var ids = [...new Set(idsInput.split(/[\n,]+/).map(function(s) { return s.trim(); }).filter(Boolean))];
    if (ids.length > 50) { setStatus("erp-batch-status", "❌ 每次最多 50 个", "err"); return; }
    setStatus("erp-batch-status", "⏳ 正在查询 " + ids.length + " 个...");
    document.getElementById("erp-batch-result").innerHTML = "";
    document.getElementById("erp-export-csv").style.display = "none";
    chrome.runtime.sendMessage({ action: "queryItems", ids }, function(response) {
      if (!response || !response.success) { setStatus("erp-batch-status", "❌ 查询失败：" + (response?.error || "未知"), "err"); return; }
      var data = response.data;
      if (!data || data.code !== 0 || !Array.isArray(data.data)) { setStatus("erp-batch-status", "❌ 接口报错：" + (data?.msg || "未知"), "err"); return; }
      allData = data.data;
      setStatus("erp-batch-status", "✅ 完成，共 " + allData.length + " 条");
      renderBatchResult(allData, "erp-batch-result");
      if (allData.length > 0) document.getElementById("erp-export-csv").style.display = "block";
    });
  });

  document.getElementById("erp-clear-batch").addEventListener("click", function() {
    document.getElementById("erp-batch-ids").value = "";
    document.getElementById("erp-batch-result").innerHTML = "";
    document.getElementById("erp-batch-status").innerHTML = "";
    document.getElementById("erp-export-csv").style.display = "none";
    allData = [];
  });

  document.getElementById("erp-export-csv").addEventListener("click", function() {
    exportCSV(allData, "ozon_批量分析");
  });

  // ===== 用当前商品填充跟卖 =====
  document.getElementById("erp-follow-current").addEventListener("click", function() {
    var id = extractIdFromUrl(location.href);
    if (!id) { setStatus("erp-follow-status", "❌ 当前页面不是 Ozon 商品页", "err"); return; }
    document.getElementById("followSkuInput").value = id;
    if (lastSingleItem) {
      document.getElementById("followProductInfo").style.display = "block";
      document.getElementById("followSkuShow").textContent = id;
      document.getElementById("followNameShow").textContent = lastSingleItem.skuName || "";
      document.getElementById("followNameInput").value = lastSingleItem.skuName || "";
    }
    setStatus("erp-follow-status", "✅ 已获取当前商品 SKU：" + id);
  });

  // ===== 一键跟卖 =====
  document.getElementById("erp-follow-submit").addEventListener("click", function() {
    var sku = document.getElementById("followSkuInput").value.trim();
    var name = document.getElementById("followNameInput").value.trim();
    var price = document.getElementById("followPrice").value.trim();
    var quantity = document.getElementById("followQuantity").value.trim();
    var warehouseId = document.getElementById("followWarehouse").value
      || document.getElementById("followWarehouseManual").value.trim();
    var stockDelay = parseInt(document.getElementById("followStockDelay").value) || 0;
    var enableWatermark = document.getElementById("enableWatermark")
      ? document.getElementById("enableWatermark").checked : true;
    var wmSelectIdx = document.getElementById("watermarkSelect")
      ? document.getElementById("watermarkSelect").value : "";

    if (!sku || !price) { setStatus("erp-follow-status", "❌ 请填写 SKU 和价格", "err"); return; }
    if (quantity && !warehouseId) { setStatus("erp-follow-status", "❌ 填了库存请同时选择仓库", "err"); return; }

    var btn = document.getElementById("erp-follow-submit");
    btn.disabled = true; btn.textContent = "⏳ 提交中...";
    setStatus("erp-follow-status", "⏳ 正在处理，请稍候...");

    chrome.runtime.sendMessage({
      action: "followSell",
      sku: parseInt(sku), price: parseInt(price),
      quantity: quantity ? parseInt(quantity) : null,
      warehouse_id: warehouseId ? parseInt(warehouseId) : null,
      stock_delay: stockDelay,
      name: name || "",
      enableWatermark: enableWatermark,
      watermarkIndex: wmSelectIdx !== "" ? parseInt(wmSelectIdx) : -1
    }, function(response) {
      btn.disabled = false; btn.textContent = "🛍️ 一键跟卖";
      if (!response || !response.success) {
        setStatus("erp-follow-status", "❌ 提交失败：" + (response?.error || "未知"), "err"); return;
      }
      var data = response.data;
      if (data && data.code === 0) {
        var info = data.data || {};
        var msg = "✅ 跟卖成功！";
        if (info.offer_id) msg += " | offer_id: " + info.offer_id;
        if (info.imageCount) msg += " | 📸 " + info.imageCount + " 张";
        if (info.stockDelayed) msg += " | ⏰ " + stockDelay + " 分钟后加库存";
        else if (info.stockSet) msg += " | 📦 库存已设置";
        setStatus("erp-follow-status", msg);
        document.getElementById("followSkuInput").value = "";
        document.getElementById("followNameInput").value = "";
        document.getElementById("followPrice").value = "";
        document.getElementById("followQuantity").value = "";
        document.getElementById("followProductInfo").style.display = "none";
      } else if (data && data.code === 202) {
        setStatus("erp-follow-status", "⏳ 商品创建中，请稍后查看");
      } else {
        setStatus("erp-follow-status", "❌ " + (data?.msg || "失败"), "err");
      }
    });
  });

  // ===== 收藏功能 =====
  document.getElementById("erp-refresh-favorites").addEventListener("click", function() {
    if (!favorites.length) { setStatus("erp-favorites-status", "❌ 收藏为空", "err"); return; }
    var ids = favorites.map(function(i) { return String(i.itemId); });
    setStatus("erp-favorites-status", "⏳ 刷新中...");
    chrome.runtime.sendMessage({ action: "queryItems", ids }, function(response) {
      if (!response || !response.success || !response.data || !response.data.data) {
        setStatus("erp-favorites-status", "❌ 刷新失败", "err"); return;
      }
      favorites = response.data.data; saveFavorites(); renderFavorites();
      setStatus("erp-favorites-status", "✅ 刷新成功");
    });
  });

  document.getElementById("erp-export-favorites").addEventListener("click", function() {
    if (!favorites.length) { setStatus("erp-favorites-status", "❌ 收藏为空", "err"); return; }
    exportCSV(favorites, "ozon_收藏列表");
  });

  document.getElementById("erp-clear-favorites").addEventListener("click", function() {
    if (!confirm("确定清空所有收藏吗？")) return;
    favorites = []; saveFavorites(); renderFavorites();
    setStatus("erp-favorites-status", "✅ 已清空");
  });

  // ===== 列表页懒加载注入 =====

  // 初始化 IntersectionObserver
  function initCardObserver() {
    if (cardObserver) return;
    cardObserver = new IntersectionObserver(function(entries) {
      var visibleSkus = [];
      entries.forEach(function(entry) {
        if (!entry.isIntersecting) return;
        var container = entry.target;
        var sku = container.getAttribute("data-erp-pending");
        if (!sku) return;
        visibleSkus.push(sku);
        // 停止观察这个元素
        cardObserver.unobserve(container);
        container.removeAttribute("data-erp-pending");
      });
      if (visibleSkus.length > 0) {
        loadVisibleCards(visibleSkus);
      }
    }, {
      root: null,
      rootMargin: "200px", // 提前 200px 开始加载，用户滚到前就准备好
      threshold: 0
    });
  }

  // 处理可见的商品卡片
  async function loadVisibleCards(skus) {
    // 用并发控制，同时最多 ERP_LIST_CONCURRENCY 个请求
    var index = 0;
    async function worker() {
      while (index < skus.length) {
        var i = index++;
        var sku = skus[i];
        var info = pendingCards.get(sku);
        if (!info || !info.container.isConnected) {
          pendingCards.delete(sku);
          continue;
        }

        // 显示加载中
        info.container.innerHTML =
          '<div style="text-align:center;color:#1677ff;font-size:11px;padding:6px;">⏳ 加载中...</div>';

        var itemData = null;

        // 先查缓存
        if (erpListItemCache.has(sku)) {
          itemData = erpListItemCache.get(sku);
        } else {
          var res = await new Promise(function(resolve) {
            chrome.runtime.sendMessage({ action: "querySingle", id: sku }, resolve);
          });
          if (res && res.success && res.data && res.data.code === 0
            && res.data.data && hasValidItemData(res.data.data)) {
            itemData = res.data.data;
            erpListItemCache.set(sku, itemData);
          }
        }

        if (!info.container.isConnected) { pendingCards.delete(sku); continue; }

        if (itemData) {
          renderListDataCard(info.container, itemData, sku);
        } else {
          info.container.innerHTML =
            '<div style="text-align:center;color:#ff4d4f;font-size:11px;">⚠️ 数据未收录</div>' +
            '<div style="text-align:center;font-size:10px;color:#999;">SKU: ' + sku + "</div>";
        }

        pendingCards.delete(sku);
      }
    }

    var workers = [];
    for (var w = 0; w < Math.min(ERP_LIST_CONCURRENCY, skus.length); w++) {
      workers.push(worker());
    }
    await Promise.all(workers);
  }

  // 扫描页面上所有商品卡片，添加占位符并注册观察
  function scanAndRegisterCards() {
    if (!isOzonListPage()) return;

    initCardObserver();

    var allCards = Array.from(document.querySelectorAll(".tile-root")).filter(function(card) {
      return card.querySelector('a[href*="/product/"]');
    });

    allCards.forEach(function(card) {
      var link = card.querySelector('a[href*="/product/"]');
      if (!link) return;
      var href = link.getAttribute("href") || link.href || "";
      var sku = extractIdFromUrl(href);
      if (!sku) return;

      // 已经注入过的跳过
      if (card.querySelector('[data-erp-card="' + sku + '"]')) return;
      // 已经在待处理队列的跳过
      if (pendingCards.has(sku)) return;

      // 创建占位容器
      var cardContainer = document.createElement("div");
      cardContainer.setAttribute("data-erp-card", sku);
      cardContainer.setAttribute("data-erp-pending", sku);
      cardContainer.style.cssText =
        "background:#f0f5ff;border:1px solid #1677ff;border-radius:8px;" +
        "padding:8px 10px;margin-top:6px;font-size:12px;color:#333;" +
        "box-shadow:0 2px 4px rgba(22,119,255,0.08);min-height:32px;";

      // 占位内容（进入视口前显示）
      cardContainer.innerHTML =
        '<div style="text-align:center;color:#91caff;font-size:11px;">📊 滚动到此处加载数据</div>';

      card.appendChild(cardContainer);

      // 注册到待处理队列
      pendingCards.set(sku, { card: card, container: cardContainer });

      // 注册观察
      cardObserver.observe(cardContainer);
    });
  }

  function scheduleInjectProductCards(delay) {
    clearTimeout(erpListInjectTimer);
    erpListInjectTimer = setTimeout(function() {
      if (erpListInjecting) {
        erpListNeedRerun = true;
        return;
      }
      erpListInjecting = true;
      erpListNeedRerun = false;
      try {
        scanAndRegisterCards();
      } finally {
        erpListInjecting = false;
        if (erpListNeedRerun) {
          scheduleInjectProductCards(500);
        }
      }
    }, delay || 1000);
  }

  function renderListDataCard(cardContainer, item, sku) {
    cardContainer.innerHTML =
      '<div style="font-weight:bold;color:#1677ff;margin-bottom:6px;border-bottom:1px solid #d0e4ff;padding-bottom:4px;font-size:11px;">📊 商品数据</div>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:8px;">' +
      '<div><div style="color:#999;font-size:10px;">月销量</div><div style="font-weight:bold;color:#52c41a;font-size:12px;">' + (item.monthSales || "-") + "</div></div>" +
      '<div><div style="color:#999;font-size:10px;">月销额¥</div><div style="font-weight:bold;color:#1677ff;font-size:12px;">' + (item.monthGmvRmb || "-") + "</div></div>" +
      '<div><div style="color:#999;font-size:10px;">均价¥</div><div style="font-weight:bold;font-size:11px;">' + (item.avgPriceRmb || "-") + "</div></div>" +
      '<div><div style="color:#999;font-size:10px;">访客</div><div style="font-weight:bold;font-size:11px;">' + (item.sessionCount || "-") + "</div></div>" +
      '<div><div style="color:#999;font-size:10px;">点击率</div><div style="font-weight:bold;font-size:11px;">' + (item.clickRatio || "-") + "%</div></div>" +
      '<div><div style="color:#999;font-size:10px;">加购率</div><div style="font-weight:bold;font-size:11px;">' + (item.convToCartPdp || "-") + "</div></div>" +
      '<div style="grid-column:1/-1;"><div style="color:#999;font-size:10px;">重量/尺寸</div><div style="font-size:10px;font-weight:bold;">' +
      (item.weight || "-") + "kg | " + (item.dimensionsLength || "-") + "×" + (item.dimensionsWidth || "-") + "×" + (item.dimensionsHeight || "-") + "cm</div></div>" +
      '</div>' +
      '<div style="border-top:1px solid #e8e8e8;padding-top:6px;">' +
      '<button data-role="follow" style="width:100%;background:#1677ff;color:#fff;border:none;border-radius:4px;padding:5px;cursor:pointer;font-size:11px;font-weight:bold;">🛍️ 跟卖</button>' +
      "</div>";

    cardContainer.querySelector('[data-role="follow"]').addEventListener("click", function() {
      var skuInput = document.getElementById("followSkuInput");
      var nameInput = document.getElementById("followNameInput");
      var infoBox = document.getElementById("followProductInfo");
      var skuShow = document.getElementById("followSkuShow");
      var nameShow = document.getElementById("followNameShow");
      if (skuInput) skuInput.value = String(sku);
      if (nameInput) nameInput.value = item.skuName || "";
      if (infoBox) infoBox.style.display = "block";
      if (skuShow) skuShow.textContent = String(sku);
      if (nameShow) nameShow.textContent = item.skuName || "";
      switchToFollowTab();
      setStatus("erp-follow-status", "✅ 已填充商品：" + sku);
    });
  }

  function autoLoadCurrentItem() {
    if (!isOzonProductPage()) return;
    var id = extractIdFromUrl(location.href);
    if (!id) return;
    if (lastAutoLoadedProductId === id && lastSingleItem && String(lastSingleItem.itemId) === String(id)) return;
    lastAutoLoadedProductId = id;
    console.log("🔍 [ERP] 自动加载 SKU:", id);
    var followSkuInput = document.getElementById("followSkuInput");
    if (followSkuInput) followSkuInput.value = id;
    container.classList.add("show");
    miniBtn.classList.remove("show");
    container.querySelectorAll(".erp-tab").forEach(function(t) { t.classList.remove("active"); });
    container.querySelectorAll(".erp-panel").forEach(function(p) { p.classList.remove("active"); });
    container.querySelector('.erp-tab[data-tab="query"]').classList.add("active");
    document.getElementById("panel-query").classList.add("active");
    setStatus("erp-single-status", "⏳ 查询中...");
    document.getElementById("erp-single-result").innerHTML = "";
    chrome.runtime.sendMessage({ action: "querySingle", id }, function(response) {
      var ok = handleSingleQueryResult(response, id, true);
      if (ok) console.log("✅ [ERP] 当前商品数据已显示");
    });
  }

  // ===== 初始化 =====
  chrome.storage.local.get(["erp_favorites", "erp_token", "erp_user"], function(res) {
    favorites = res.erp_favorites || [];
    console.log("✅ [ERP] 收藏已加载，数量:", favorites.length);
    if (res.erp_token && res.erp_user) {
      showLoggedIn(res.erp_user);
      console.log("✅ [ERP] 已登录:", res.erp_user.username);
    } else {
      showLoggedOut();
    }
    miniBtn.classList.add("show");
  });

  setTimeout(function() {
    scheduleInjectProductCards(1200);
    autoLoadCurrentItem();
  }, 1800);

  // URL 变化监听
  setInterval(function() {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      // URL 变化时清空缓存和待处理队列
      pendingCards.clear();
      if (cardObserver) { cardObserver.disconnect(); cardObserver = null; }
      setTimeout(function() {
        scheduleInjectProductCards(1200);
        autoLoadCurrentItem();
      }, 1200);
    }
  }, 1000);

  // DOM 变化监听（滚动加载新商品）
  var domObserver = new MutationObserver(function(mutations) {
    if (!isOzonListPage()) return;
    var hasNewTile = mutations.some(function(m) {
      return Array.from(m.addedNodes || []).some(function(node) {
        return node.nodeType === 1 && (
          (node.matches && node.matches(".tile-root")) ||
          (node.querySelector && node.querySelector(".tile-root"))
        );
      });
    });
    if (hasNewTile) {
      // 新商品出现，扫描并注册（不立即请求，等滚动到可视区域）
      scheduleInjectProductCards(600);
    }
  });

  domObserver.observe(document.body, { childList: true, subtree: true });

  console.log("✅ [ERP] 所有功能已初始化");
})();
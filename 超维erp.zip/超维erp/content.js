console.log("✅ [ERP] 超维 ERP v7.1 已加载（登录同步版）");

(function () {
  if (document.getElementById("ozon-erp-floating")) return;

  // ===== 工具函数 =====
  function sendBgMessage(payload) {
    return new Promise(function(resolve) {
      chrome.runtime.sendMessage(payload, function(resp) {
        if (chrome.runtime.lastError) {
          resolve({ success: false, error: chrome.runtime.lastError.message });
        } else {
          resolve(resp);
        }
      });
    });
  }

  var lastSingleItem = null;
  var lastUrl = location.href;
  var lastAutoLoadedProductId = null;
  var favorites = [];
  var ERP_LIST_CONCURRENCY = 5;
  var erpListInjecting = false;
  var erpListInjectTimer = null;
  var erpListNeedRerun = false;
  var erpListItemCache = new Map();
  var cardObserver = null;
  var pendingCards = new Map();
  var isLoggedIn = false;
  var currentErpUser = null;

  // ===== 浮窗主体 =====
  var container = document.createElement("div");
  container.id = "ozon-erp-floating";
  container.style.cssText = [
    "position:fixed", "top:80px", "right:20px", "width:340px", "max-height:70vh",
    "background:#fff", "border:1px solid #d9d9d9", "border-radius:12px",
    "box-shadow:0 8px 24px rgba(0,0,0,0.15)", "z-index:999999",
    "font-family:Arial,sans-serif", "display:none", "overflow:hidden",
    "flex-direction:column", "font-size:12px"
  ].join(";");

  container.innerHTML = [
    // 标题栏
    '<div style="display:flex;align-items:center;justify-content:space-between;',
      'padding:10px 14px;background:#1677ff;color:#fff;cursor:move;',
      'user-select:none;flex-shrink:0;" id="erp-header">',
      '<div style="font-weight:bold;font-size:14px;">🔍 超维 ERP</div>',
      '<div style="display:flex;gap:10px;">',
        '<span id="erp-minimize" style="cursor:pointer;font-size:16px;">—</span>',
        '<span id="erp-close" style="cursor:pointer;font-size:16px;">✕</span>',
      '</div>',
    '</div>',

    // ===== 登录页（居中）=====
    '<div id="erp-login-page" style="',
      'display:flex;flex-direction:column;align-items:center;justify-content:center;',
      'flex:1;padding:24px 20px;background:#fff;min-height:280px;',
    '">',
      '<div style="text-align:center;margin-bottom:24px;">',
        '<div style="font-size:36px;margin-bottom:8px;">🔍</div>',
        '<div style="font-size:16px;font-weight:bold;color:#1677ff;">超维 ERP</div>',
        '<div style="font-size:11px;color:#999;margin-top:4px;">请登录后使用</div>',
      '</div>',
      '<div style="width:100%;">',
        '<div style="margin-bottom:12px;">',
          '<input id="erp-login-user" type="text" placeholder="用户名" style="',
            'width:100%;padding:10px 12px;border:1.5px solid #e2e8f0;border-radius:8px;',
            'font-size:13px;outline:none;box-sizing:border-box;" />',
        '</div>',
        '<div style="margin-bottom:16px;">',
          '<input id="erp-login-pass" type="password" placeholder="密码" style="',
            'width:100%;padding:10px 12px;border:1.5px solid #e2e8f0;border-radius:8px;',
            'font-size:13px;outline:none;box-sizing:border-box;" />',
        '</div>',
        '<div id="erp-login-tip" style="min-height:18px;margin-bottom:10px;font-size:11px;color:#ff4d4f;text-align:center;"></div>',
        '<button id="erp-login-btn" style="',
          'width:100%;padding:11px;background:#1677ff;color:#fff;border:none;border-radius:8px;',
          'font-size:14px;font-weight:bold;cursor:pointer;">登录</button>',
      '</div>',
      '<div style="margin-top:16px;font-size:11px;color:#bbb;text-align:center;">',
        '还没有账号？前往 <a href="https://ozon.chaowei.online" target="_blank" style="color:#1677ff;text-decoration:none;">chaowei.online</a> 注册',
      '</div>',
    '</div>',

    // ===== 主功能区（登录后）=====
    '<div id="erp-main-area" style="display:none;flex:1;overflow:hidden;flex-direction:column;">',
      '<div id="erp-user-bar" style="',
        'background:#f6ffed;border-bottom:1px solid #b7eb8f;padding:6px 14px;',
        'display:flex;align-items:center;justify-content:space-between;flex-shrink:0;font-size:11px;">',
        '<span style="color:#52c41a;font-weight:bold;">✅ <span id="erp-username-display"></span></span>',
        '<span id="erp-logout-btn" style="color:#999;cursor:pointer;font-size:11px;padding:2px 6px;border-radius:4px;">退出</span>',
      '</div>',
      '<div style="overflow-y:auto;flex:1;padding:12px;" id="erp-body">',
        '<div id="erp-loading" style="text-align:center;padding:20px;color:#999;">',
          '<div style="font-size:20px;margin-bottom:8px;">⏳</div><div>等待商品页面...</div>',
        '</div>',
        '<div id="erp-result" style="display:none;"></div>',
      '</div>',
    '</div>'
  ].join("");

  document.body.appendChild(container);

  var miniBtn = document.createElement("div");
  miniBtn.id = "ozon-erp-mini";
  miniBtn.innerHTML = "🔍";
  miniBtn.style.cssText = [
    "position:fixed", "right:20px", "bottom:24px", "width:48px", "height:48px",
    "border-radius:50%", "background:#1677ff", "color:#fff", "display:none",
    "align-items:center", "justify-content:center", "font-size:22px", "cursor:pointer",
    "z-index:999999", "box-shadow:0 8px 20px rgba(22,119,255,.35)"
  ].join(";");
  document.body.appendChild(miniBtn);

  // ===== 工具 =====
  function escapeHtml(s) {
    return String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  function extractIdFromUrl(url) {
    var match = String(url || "").match(/\/product\/.*?-(\d{7,15})(?:\/|\?|$)|\/product\/(\d{7,15})(?:\/|\?|$)/);
    return match ? match[1] || match[2] : null;
  }

  function hasValidItemData(item) {
    if (!item) return false;
    var fields = [item.itemId, item.skuName, item.catNamePath, item.photo, item.brand,
      item.monthSales, item.monthGmvRmb, item.avgPriceRmb, item.sessionCount,
      item.clickRatio, item.convToCartPdp, item.weight, item.dimensionsLength,
      item.dimensionsWidth, item.dimensionsHeight, item.sources, item.logDate];
    for (var i = 0; i < fields.length; i++) {
      if (fields[i] !== null && fields[i] !== undefined && fields[i] !== "") return true;
    }
    return false;
  }

  function isOzonProductPage() { return /\/product\//.test(location.pathname); }

  function isOzonListPage() {
    if (isOzonProductPage()) return false;
    var p = location.pathname || "";
    if (p.includes("/search") || p.includes("/category") || p.includes("/seller")) return true;
    return document.querySelectorAll('.tile-root a[href*="/product/"]').length >= 4;
  }

  function isFavorited(itemId) {
    return favorites.some(function(f) { return String(f.itemId) === String(itemId); });
  }

  function toggleFavorite(itemId) {
    var idx = favorites.findIndex(function(f) { return String(f.itemId) === String(itemId); });
    if (idx === -1 && lastSingleItem && String(lastSingleItem.itemId) === String(itemId)) {
      favorites.push(lastSingleItem);
    } else if (idx !== -1) {
      favorites.splice(idx, 1);
    }
    chrome.runtime.sendMessage({ action: "saveFavorites", favorites: favorites });
    var star = document.getElementById("erp-fav-star");
    if (star) star.textContent = isFavorited(itemId) ? "⭐" : "☆";
  }

  // ===== 登录态切换 =====
  function showLoginPage() {
    isLoggedIn = false;
    currentErpUser = null;
    document.getElementById("erp-login-page").style.display = "flex";
    document.getElementById("erp-main-area").style.display = "none";
    document.getElementById("erp-login-user").value = "";
    document.getElementById("erp-login-pass").value = "";
    document.getElementById("erp-login-tip").textContent = "";
  }

  function showMainPage(user) {
    isLoggedIn = true;
    currentErpUser = user;
    document.getElementById("erp-login-page").style.display = "none";
    var mainArea = document.getElementById("erp-main-area");
    mainArea.style.display = "flex";
    var nameEl = document.getElementById("erp-username-display");
    if (nameEl) nameEl.textContent = (user && user.username) ? user.username : "已登录";
    loadFavorites();
    autoLoadCurrentItem();
    scheduleInjectProductCards(800);
  }

  // =============================================
  // ===== 核心：登录态双向同步 =====
  // =============================================

  // ✅ 1. 网页端登录 → 写入 storage → 插件自动同步
  //    （由 injectWebPageBridge 实现）

  // ✅ 2. 监听 storage 变化（来自网页端或其他 tab）
  chrome.storage.onChanged.addListener(function(changes, area) {
    if (area !== "local") return;
    if (changes.erp_token || changes.erp_user) {
      var newToken = changes.erp_token ? changes.erp_token.newValue : undefined;
      var newUser = changes.erp_user ? changes.erp_user.newValue : undefined;

      if (newToken === undefined && changes.erp_token) {
        // token 被删除 = 退出登录
        if (isLoggedIn) showLoginPage();
      } else if (newToken && newUser) {
        // 新登录
        if (!isLoggedIn) showMainPage(newUser);
      }
    }
  });

  // ✅ 3. 监听 background 广播的登录态变化
  chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
    if (msg.action === "erpAuthChanged") {
      if (msg.loggedOut) {
        if (isLoggedIn) showLoginPage();
      } else if (msg.token && msg.user) {
        if (!isLoggedIn) showMainPage(msg.user);
      }
      sendResponse({ success: true });
    }

    if (msg.action === "toggleFloating") {
      if (container.style.display === "flex") {
        container.style.display = "none"; miniBtn.style.display = "flex";
      } else {
        container.style.display = "flex"; miniBtn.style.display = "none";
      }
      sendResponse({ success: true });
    }

    if (msg.action === "openUploadPanel") {
      if (!isLoggedIn) { sendResponse({ success: false }); return true; }
      openUploadPanel({ sku: msg.sku || "", name: msg.name || "", brand: msg.brand || "" });
      sendResponse({ success: true });
    }

    return true;
  });

  // ✅ 4. 在 chaowei.online 网页注入桥接脚本，让网页登录写入 extension storage
  function injectWebPageBridge() {
    var host = location.hostname || "";
    // 只在自己的官网注入
    if (!host.includes("chaowei.online") && !host.includes("localhost")) return;

    // 监听网页端发来的登录/登出消息
    window.addEventListener("message", function(event) {
      if (event.source !== window) return;
      var data = event.data;
      if (!data || data.source !== "erp-web") return;

      if (data.type === "erp-login" && data.token && data.user) {
        // 网页端登录 → 写入 extension storage
        chrome.storage.local.set({
          erp_token: data.token,
          erp_user: data.user
        }, function() {
          console.log("✅ [同步] 网页端登录已同步到插件");
          // 回复网页端
          window.postMessage({ source: "erp-extension", type: "erp-login-synced", success: true }, "*");
        });
      }

      if (data.type === "erp-logout") {
        chrome.storage.local.remove(["erp_token", "erp_user"], function() {
          console.log("✅ [同步] 网页端登出已同步到插件");
          window.postMessage({ source: "erp-extension", type: "erp-logout-synced", success: true }, "*");
        });
      }

      // 网页端请求当前登录状态
      if (data.type === "erp-check-auth") {
        chrome.storage.local.get(["erp_token", "erp_user"], function(res) {
          window.postMessage({
            source: "erp-extension",
            type: "erp-auth-status",
            loggedIn: !!(res.erp_token && res.erp_user),
            user: res.erp_user || null,
            token: res.erp_token || null
          }, "*");
        });
      }
    });

    // 告诉网页端：插件已加载
    window.postMessage({ source: "erp-extension", type: "erp-extension-ready" }, "*");
  }

  // ===== 登录按钮 =====
  document.getElementById("erp-login-btn").addEventListener("click", doLogin);
  document.getElementById("erp-login-pass").addEventListener("keydown", function(e) {
    if (e.key === "Enter") doLogin();
  });
  document.getElementById("erp-login-user").addEventListener("keydown", function(e) {
    if (e.key === "Enter") doLogin();
  });

  function doLogin() {
    var u = document.getElementById("erp-login-user").value.trim();
    var p = document.getElementById("erp-login-pass").value.trim();
    var tip = document.getElementById("erp-login-tip");
    var btn = document.getElementById("erp-login-btn");
    if (!u || !p) { tip.textContent = "请填写用户名和密码"; return; }
    btn.disabled = true; btn.textContent = "登录中..."; tip.textContent = "";
    chrome.runtime.sendMessage({ action: "erpLogin", username: u, password: p }, function(res) {
      btn.disabled = false; btn.textContent = "登录";
      if (res && res.success) {
        showMainPage(res.data && res.data.user ? res.data.user : null);
      } else {
        tip.textContent = "❌ " + ((res && res.error) || "登录失败");
      }
    });
  }

  // ===== 退出登录 =====
  document.getElementById("erp-logout-btn").addEventListener("click", function() {
    chrome.runtime.sendMessage({ action: "erpLogout" }, function() {
      lastSingleItem = null;
      lastAutoLoadedProductId = null;
      favorites = [];
      document.getElementById("erp-loading").innerHTML =
        '<div style="font-size:20px;margin-bottom:8px;">⏳</div><div>等待商品页面...</div>';
      document.getElementById("erp-result").style.display = "none";
      document.getElementById("erp-result").innerHTML = "";
      showLoginPage();
    });
  });

  function loadFavorites() {
    if (!isLoggedIn) return;
    chrome.runtime.sendMessage({ action: "getFavorites" }, function(res) {
      if (res && res.success && res.data && res.data.code === 0) favorites = res.data.data || [];
    });
  }

  // ===== 关闭/最小化 =====
  document.getElementById("erp-close").addEventListener("click", function() {
    container.style.display = "none"; miniBtn.style.display = "flex";
  });
  document.getElementById("erp-minimize").addEventListener("click", function() {
    container.style.display = "none"; miniBtn.style.display = "flex";
  });
  miniBtn.addEventListener("click", function() {
    miniBtn.style.display = "none"; container.style.display = "flex";
  });

  // ===== 拖拽 =====
  var header = document.getElementById("erp-header");
  var isDragging = false, startX = 0, startY = 0, startLeft = 0, startTop = 0;
  header.addEventListener("mousedown", function(e) {
    if (e.target.id === "erp-minimize" || e.target.id === "erp-close") return;
    isDragging = true;
    var rect = container.getBoundingClientRect();
    startX = e.clientX; startY = e.clientY; startLeft = rect.left; startTop = rect.top;
    document.body.style.userSelect = "none";
  });
  document.addEventListener("mousemove", function(e) {
    if (!isDragging) return;
    container.style.left = (startLeft + e.clientX - startX) + "px";
    container.style.top = (startTop + e.clientY - startY) + "px";
    container.style.right = "auto";
  });
  document.addEventListener("mouseup", function() {
    isDragging = false; document.body.style.userSelect = "";
  });

  // ===== 渲染 =====
  function showLoading(sku) {
    document.getElementById("erp-loading").style.display = "block";
    document.getElementById("erp-result").style.display = "none";
    document.getElementById("erp-loading").innerHTML =
      '<div style="font-size:20px;margin-bottom:8px;">⏳</div>' +
      '<div style="font-weight:bold;color:#1677ff;">SKU: ' + (sku || "") + '</div>' +
      '<div style="margin-top:6px;color:#999;">正在查询数据...</div>';
  }

  function renderResult(item) {
    lastSingleItem = item;
    document.getElementById("erp-loading").style.display = "none";
    var el = document.getElementById("erp-result");
    el.style.display = "block";
    var fields = [
      ["月销", (item.monthSales || "-") + " 件"], ["月销额", "¥" + (item.monthGmvRmb || "-")],
      ["均价", "¥" + (item.avgPriceRmb || "-")], ["访客", item.sessionCount || "-"],
      ["点击率", (item.clickRatio || "-") + "%"], ["加购率", item.convToCartPdp || "-"],
      ["增长", (item.monthSalesRatio || "-") + "%"], ["广告", (item.drr || "-") + "%"],
      ["发货", item.sources || "-"], ["重量", (item.weight || "-") + "kg"],
      ["尺寸", (item.dimensionsLength||"-")+"×"+(item.dimensionsWidth||"-")+"×"+(item.dimensionsHeight||"-")],
      ["日期", item.logDate || "-"]
    ];
    var html = '<div style="position:relative;">';
    html += '<span id="erp-fav-star" style="position:absolute;top:0;right:0;cursor:pointer;font-size:20px;">' + (isFavorited(item.itemId) ? "⭐" : "☆") + '</span>';
    html += '<div style="font-size:13px;font-weight:bold;color:#1677ff;margin-bottom:6px;">📊 ' + escapeHtml(String(item.itemId || "")) + '</div>';
    html += '<div style="font-size:11px;color:#333;margin-bottom:8px;">' + escapeHtml(item.skuName || "") + '</div>';
    html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:4px;">';
    fields.forEach(function(f) {
      html += '<div style="font-size:11px;"><span style="color:#999;">' + f[0] + '：</span>' + escapeHtml(String(f[1])) + '</div>';
    });
    html += '</div>';
    html += '<button id="erp-open-upload" style="width:100%;margin-top:12px;background:#1677ff;color:#fff;border:none;border-radius:6px;padding:9px;cursor:pointer;font-size:13px;font-weight:bold;">🛍️ 快速上货</button>';
    html += '</div>';
    el.innerHTML = html;

    document.getElementById("erp-fav-star").addEventListener("click", function() { toggleFavorite(item.itemId); });

    var currentItemId = String(item.itemId || "");
    var currentItemName = item.skuName || "";
    var currentItemBrand = item.brand || "";
    document.getElementById("erp-open-upload").addEventListener("click", function() {
      var nameFromPage = "";
      try {
        var titleEl = document.querySelector('h1[data-widget="webProductHeading"]') || document.querySelector("h1");
        if (titleEl) nameFromPage = (titleEl.textContent || "").trim();
      } catch (e) {}
      chrome.runtime.sendMessage({
        action: "openUploadWindow", sku: currentItemId,
        name: currentItemName || nameFromPage || "", brand: currentItemBrand || ""
      });
    });
  }

  function showError(msg) {
    document.getElementById("erp-loading").style.display = "none";
    var el = document.getElementById("erp-result");
    el.style.display = "block";
    el.innerHTML = '<div style="text-align:center;padding:20px;color:#ff4d4f;">' + escapeHtml(msg) + '</div>';
  }

  // ===== 自动查询 =====
  function autoLoadCurrentItem() {
    if (!isLoggedIn) return;
    if (!isOzonProductPage()) return;
    var id = extractIdFromUrl(location.href);
    if (!id) return;
    if (lastAutoLoadedProductId === id && lastSingleItem && String(lastSingleItem.itemId) === String(id)) return;
    lastAutoLoadedProductId = id;
    showLoading(id);
    chrome.runtime.sendMessage({ action: "querySingle", id: id }, function(response) {
      if (!isLoggedIn) return;
      if (!response || !response.success) { showError("查询失败：" + ((response && response.error) || "未知")); return; }
      var data = response.data;
      if (!data || data.code !== 0 || !data.data) { showError((data && data.msg) || "未收录"); return; }
      renderResult(data.data);
    });
  }

  // ===== 列表页 =====
  function initCardObserver() {
    if (cardObserver) return;
    cardObserver = new IntersectionObserver(function(entries) {
      var skus = [];
      entries.forEach(function(entry) {
        if (!entry.isIntersecting) return;
        var c = entry.target;
        var sku = c.getAttribute("data-erp-pending");
        if (!sku) return;
        skus.push(sku);
        cardObserver.unobserve(c);
        c.removeAttribute("data-erp-pending");
      });
      if (skus.length > 0) loadVisibleCards(skus);
    }, { root: null, rootMargin: "200px", threshold: 0 });
  }

  async function loadVisibleCards(skus) {
    if (!isLoggedIn) return;
    var idx = 0;
    async function worker() {
      while (idx < skus.length) {
        var i = idx++;
        var sku = skus[i];
        var info = pendingCards.get(sku);
        if (!info || !info.container.isConnected) { pendingCards.delete(sku); continue; }
        info.container.innerHTML = '<div style="text-align:center;color:#1677ff;font-size:10px;">⏳</div>';
        var itemData = erpListItemCache.has(sku) ? erpListItemCache.get(sku) : null;
        if (!itemData) {
          var res = await new Promise(function(resolve) {
            chrome.runtime.sendMessage({ action: "querySingle", id: sku }, resolve);
          });
          if (res && res.success && res.data && res.data.code === 0 && res.data.data && hasValidItemData(res.data.data)) {
            itemData = res.data.data;
            erpListItemCache.set(sku, itemData);
          }
        }
        if (!info.container.isConnected) { pendingCards.delete(sku); continue; }
        info.container.innerHTML = itemData
          ? '<div style="display:grid;grid-template-columns:1fr 1fr;gap:2px;font-size:10px;"><div><span style="color:#999;">月销</span><div style="font-weight:bold;color:#52c41a;">' + (itemData.monthSales || "-") + '</div></div><div><span style="color:#999;">均价</span><div style="font-weight:bold;">¥' + (itemData.avgPriceRmb || "-") + '</div></div></div>'
          : '<div style="text-align:center;color:#ccc;font-size:9px;">未收录</div>';
        pendingCards.delete(sku);
      }
    }
    var workers = [];
    for (var w = 0; w < Math.min(ERP_LIST_CONCURRENCY, skus.length); w++) workers.push(worker());
    await Promise.all(workers);
  }

  function scanAndRegisterCards() {
    if (!isLoggedIn) return;
    if (!isOzonListPage()) return;
    initCardObserver();
    Array.from(document.querySelectorAll(".tile-root")).filter(function(card) {
      return card.querySelector('a[href*="/product/"]');
    }).forEach(function(card) {
      var link = card.querySelector('a[href*="/product/"]');
      if (!link) return;
      var sku = extractIdFromUrl(link.getAttribute("href") || link.href || "");
      if (!sku || card.querySelector('[data-erp-card="' + sku + '"]') || pendingCards.has(sku)) return;
      var c = document.createElement("div");
      c.setAttribute("data-erp-card", sku);
      c.setAttribute("data-erp-pending", sku);
      c.style.cssText = "background:#f0f5ff;border:1px solid #91caff;border-radius:4px;padding:3px 6px;margin-top:3px;min-height:20px;";
      c.innerHTML = '<div style="text-align:center;color:#91caff;font-size:9px;">📊</div>';
      card.appendChild(c);
      pendingCards.set(sku, { card: card, container: c });
      cardObserver.observe(c);
    });
  }

  function scheduleInjectProductCards(delay) {
    if (!isLoggedIn) return;
    clearTimeout(erpListInjectTimer);
    erpListInjectTimer = setTimeout(function() {
      if (erpListInjecting) { erpListNeedRerun = true; return; }
      erpListInjecting = true; erpListNeedRerun = false;
      try { scanAndRegisterCards(); } finally {
        erpListInjecting = false;
        if (erpListNeedRerun) scheduleInjectProductCards(500);
      }
    }, delay || 1000);
  }

  // ===== 上货面板 =====
  var uploadPanel = null;
  var uploadMask = null;
  var uploadState = { sku: "", name: "", brand: "", stores: [] };

  function ensureUploadPanel() {
    if (uploadPanel) return;
    uploadMask = document.createElement("div");
    uploadMask.id = "erp-upload-mask";
    uploadMask.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.35);z-index:999998;display:none;backdrop-filter:blur(2px);";
    uploadMask.addEventListener("click", closeUploadPanel);

    uploadPanel = document.createElement("div");
    uploadPanel.id = "erp-upload-panel";
    uploadPanel.style.cssText = [
      "position:fixed","top:0","right:-440px","width:420px","height:100vh",
      "background:#f8f9fb","z-index:999999","box-shadow:-8px 0 30px rgba(0,0,0,.12)",
      "transition:right .3s cubic-bezier(.4,0,.2,1)","display:flex","flex-direction:column",
      "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif",
      "font-size:13px","color:#333"
    ].join(";");

    uploadPanel.innerHTML = [
      '<div style="padding:16px 20px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;display:flex;align-items:center;justify-content:space-between;flex-shrink:0;">',
        '<div style="display:flex;align-items:center;gap:10px;">',
          '<div style="width:32px;height:32px;background:rgba(255,255,255,.2);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;">🛍️</div>',
          '<div><div style="font-size:16px;font-weight:700;">快速上货</div><div style="font-size:11px;opacity:.8;margin-top:2px;">一键跟卖到多个店铺</div></div>',
        '</div>',
        '<div id="erp-upload-close" style="width:28px;height:28px;background:rgba(255,255,255,.15);border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:14px;">✕</div>',
      '</div>',
      '<div style="flex:1;overflow-y:auto;padding:16px;">',
        '<div style="background:linear-gradient(135deg,#f5f3ff,#ede9fe);border:1px solid #ddd6fe;border-radius:12px;padding:14px 16px;margin-bottom:14px;">',
          '<div style="font-size:12px;font-weight:700;color:#7c3aed;margin-bottom:10px;">📦 商品信息</div>',
          '<div style="display:grid;grid-template-columns:auto 1fr;gap:4px 10px;font-size:12px;line-height:1.8;">',
            '<span style="color:#8b5cf6;font-weight:600;">SKU</span><span id="erp-upload-sku">-</span>',
            '<span style="color:#8b5cf6;font-weight:600;">名称</span><span id="erp-upload-name" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">-</span>',
            '<span style="color:#8b5cf6;font-weight:600;">品牌</span><span id="erp-upload-brand">-</span>',
          '</div>',
        '</div>',
        '<div style="margin-bottom:14px;"><label style="display:block;font-size:12px;font-weight:600;color:#555;margin-bottom:6px;">💰 价格（人民币）</label><input id="erp-upload-price" type="number" placeholder="输入售价" style="width:100%;padding:10px 14px;border:1.5px solid #e2e8f0;border-radius:10px;font-size:14px;outline:none;background:#fff;box-sizing:border-box;" /></div>',
        '<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:14px 16px;margin-bottom:14px;"><div style="font-size:12px;font-weight:700;color:#555;margin-bottom:8px;">🏪 选择店铺</div><div id="erp-upload-stores"><div style="text-align:center;color:#999;padding:12px;">⏳ 加载中...</div></div></div>',
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px;">',
          '<div><label style="display:block;font-size:12px;font-weight:600;color:#555;margin-bottom:6px;">🎨 水印</label><select id="erp-upload-watermark" style="width:100%;padding:9px 10px;border:1.5px solid #e2e8f0;border-radius:10px;font-size:12px;outline:none;background:#fff;box-sizing:border-box;"><option value="-1">不加水印</option></select></div>',
          '<div><label style="display:block;font-size:12px;font-weight:600;color:#555;margin-bottom:6px;">⏰ 库存时间</label><select id="erp-upload-delay" style="width:100%;padding:9px 10px;border:1.5px solid #e2e8f0;border-radius:10px;font-size:12px;outline:none;background:#fff;box-sizing:border-box;"><option value="0">立即添加</option><option value="5">5分钟后</option><option value="10">10分钟后</option><option value="30">30分钟后</option><option value="60">1小时后</option></select></div>',
        '</div>',
        '<div style="margin-bottom:14px;"><label style="display:block;font-size:12px;font-weight:600;color:#555;margin-bottom:6px;">📊 库存数量</label><input id="erp-upload-quantity" type="number" placeholder="不填不设库存" style="width:100%;padding:10px 14px;border:1.5px solid #e2e8f0;border-radius:10px;font-size:13px;outline:none;background:#fff;box-sizing:border-box;" /></div>',
        '<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:14px 16px;margin-bottom:16px;"><div style="font-size:12px;font-weight:700;color:#555;margin-bottom:8px;">🏭 各店铺仓库</div><div id="erp-upload-warehouses"><div style="color:#999;font-size:11px;">请先选择店铺</div></div></div>',
        '<button id="erp-upload-submit" style="width:100%;padding:13px;border:none;border-radius:12px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;font-weight:700;cursor:pointer;font-size:15px;">🛍️ 确认上货</button>',
        '<div id="erp-upload-status" style="margin-top:12px;font-size:12px;color:#555;line-height:1.8;word-break:break-all;min-height:20px;"></div>',
      '</div>'
    ].join("");

    document.body.appendChild(uploadMask);
    document.body.appendChild(uploadPanel);
    document.getElementById("erp-upload-close").addEventListener("click", closeUploadPanel);
    document.getElementById("erp-upload-submit").addEventListener("click", submitUploadPanel);
  }

  function openUploadPanel(data) {
    if (!isLoggedIn) return;
    ensureUploadPanel();
    uploadState.sku = String(data.sku || "");
    uploadState.name = data.name || "";
    uploadState.brand = data.brand || "";
    uploadState.stores = [];
    if (!uploadState.name) {
      try { var t = document.querySelector('h1[data-widget="webProductHeading"]') || document.querySelector("h1"); if (t) uploadState.name = (t.textContent || "").trim(); } catch(e) {}
    }
    document.getElementById("erp-upload-sku").textContent = uploadState.sku || "-";
    document.getElementById("erp-upload-name").textContent = uploadState.name || "-";
    document.getElementById("erp-upload-brand").textContent = uploadState.brand || "-";
    document.getElementById("erp-upload-price").value = "";
    document.getElementById("erp-upload-quantity").value = "";
    document.getElementById("erp-upload-status").innerHTML = "";
    uploadMask.style.display = "block";
    setTimeout(function() { uploadPanel.style.right = "0"; }, 10);
    loadUploadStores();
    loadUploadWatermarks();
  }

  function closeUploadPanel() {
    if (!uploadPanel || !uploadMask) return;
    uploadPanel.style.right = "-440px";
    setTimeout(function() { if (uploadMask) uploadMask.style.display = "none"; }, 300);
  }

  async function loadUploadStores() {
    if (!isLoggedIn) return;
    var el = document.getElementById("erp-upload-stores");
    el.innerHTML = '<div style="text-align:center;color:#999;">⏳ 加载中...</div>';
    var res = await sendBgMessage({ action: "getStores" });
    if (!(res && res.success && res.data && res.data.code === 0 && Array.isArray(res.data.data) && res.data.data.length > 0)) {
      el.innerHTML = '<div style="color:#999;font-size:12px;">暂无店铺，请先去后台配置</div>';
      return;
    }
    uploadState.stores = res.data.data;
    el.innerHTML = uploadState.stores.map(function(s) {
      return '<label style="display:flex;align-items:center;gap:6px;padding:3px 0;font-size:12px;cursor:pointer;"><input type="checkbox" class="erp-upload-store-cb" value="' + s.id + '" checked /><span>' + escapeHtml(s.name || "") + '</span></label>';
    }).join("");
    Array.from(el.querySelectorAll(".erp-upload-store-cb")).forEach(function(cb) { cb.addEventListener("change", loadUploadWarehouses); });
    loadUploadWarehouses();
  }

  async function loadUploadWatermarks() {
    if (!isLoggedIn) return;
    var sel = document.getElementById("erp-upload-watermark");
    sel.innerHTML = '<option value="-1">不加水印</option>';
    var res = await sendBgMessage({ action: "getWatermarks" });
    if (!(res && res.success && res.data && res.data.code === 0)) return;
    var wms = (res.data.data && res.data.data.watermarks) ? res.data.data.watermarks : [];
    wms.forEach(function(wm, idx) {
      var op = document.createElement("option"); op.value = String(idx);
      op.textContent = wm.name || ("水印" + (idx + 1)); sel.appendChild(op);
    });
    if (wms.length > 0) sel.value = "0";
  }

  async function loadUploadWarehouses() {
    if (!isLoggedIn) return;
    var box = document.getElementById("erp-upload-warehouses");
    var checked = Array.from(document.querySelectorAll(".erp-upload-store-cb:checked")).map(function(cb) { return cb.value; });
    if (checked.length === 0) { box.innerHTML = '<div style="color:#999;font-size:11px;">请先选择店铺</div>'; return; }
    box.innerHTML = '<div style="color:#999;font-size:11px;">⏳ 加载仓库...</div>';
    var html = "";
    for (var i = 0; i < checked.length; i++) {
      var sid = checked[i];
      var store = uploadState.stores.find(function(s) { return s.id === sid; });
      var sName = store ? store.name : sid;
      var res = await sendBgMessage({ action: "getStoreWarehouses", storeId: sid });
      var whs = (res && res.success && res.data && res.data.code === 0 && Array.isArray(res.data.data)) ? res.data.data : [];
      html += '<div style="margin-bottom:8px;"><div style="font-size:11px;font-weight:bold;color:#1677ff;margin-bottom:3px;">🏪 ' + escapeHtml(sName) + '</div>';
      html += '<select class="erp-upload-wh-sel" data-sid="' + sid + '" style="width:100%;padding:6px 8px;border:1px solid #d9d9d9;border-radius:6px;font-size:12px;">';
      html += '<option value="">-- ' + (whs.length ? "选择仓库" : "无仓库") + ' --</option>';
      whs.forEach(function(w) { html += '<option value="' + w.warehouse_id + '">' + escapeHtml(w.name || "") + ' (' + (w.type || "") + ')</option>'; });
      html += '</select></div>';
    }
    box.innerHTML = html;
    box.querySelectorAll(".erp-upload-wh-sel").forEach(function(sel) { if (sel.options.length === 2) sel.selectedIndex = 1; });
  }

  async function submitUploadPanel() {
    if (!isLoggedIn) return;
    var sku = uploadState.sku;
    var price = document.getElementById("erp-upload-price").value.trim();
    var quantity = document.getElementById("erp-upload-quantity").value.trim();
    var stockDelay = parseInt(document.getElementById("erp-upload-delay").value || "0", 10);
    var wmIdx = document.getElementById("erp-upload-watermark").value;
    var enableWatermark = wmIdx !== "-1";
    var watermarkIndex = enableWatermark ? parseInt(wmIdx, 10) : -1;
    var statusEl = document.getElementById("erp-upload-status");
    var btn = document.getElementById("erp-upload-submit");
    var storeIds = Array.from(document.querySelectorAll(".erp-upload-store-cb:checked")).map(function(cb) { return cb.value; });
    var warehouseIds = {};
    Array.from(document.querySelectorAll(".erp-upload-wh-sel")).forEach(function(sel) {
      var sid = sel.getAttribute("data-sid"); if (sid && sel.value) warehouseIds[sid] = sel.value;
    });
    if (!sku || !price) { statusEl.innerHTML = '<span style="color:#ff4d4f;">❌ 请填写价格</span>'; return; }
    if (storeIds.length === 0) { statusEl.innerHTML = '<span style="color:#ff4d4f;">❌ 请选择店铺</span>'; return; }
    if (quantity && Object.keys(warehouseIds).length === 0) { statusEl.innerHTML = '<span style="color:#ff4d4f;">❌ 填了库存请选仓库</span>'; return; }
    btn.disabled = true; btn.textContent = "⏳ 处理中...";
    statusEl.innerHTML = "⏳ 正在处理，请稍候（约1-3分钟）...";
    var res = await sendBgMessage({
      action: "followSell", sku: parseInt(sku, 10), price: parseInt(price, 10),
      quantity: quantity ? parseInt(quantity, 10) : null,
      storeIds: storeIds, warehouseIds: warehouseIds, stock_delay: stockDelay,
      enableWatermark: enableWatermark, watermarkIndex: watermarkIndex
    });
    btn.disabled = false; btn.textContent = "🛍️ 确认上货";
    if (!res || !res.success) { statusEl.innerHTML = '<span style="color:#ff4d4f;">❌ ' + escapeHtml((res && res.error) || "失败") + '</span>'; return; }
    var data = res.data;
    if (data && data.code === 0) {
      var d = data.data || {}; var results = d.results || [];
      if (results.length > 0) {
        statusEl.innerHTML = results.map(function(r) {
          if (r.ok && r.status === "completed") return "✅ " + escapeHtml(r.storeName || "店铺") + (r.imageUploaded ? " | 📸" + r.uploadedCount + "张" : "");
          if (r.ok && r.status === "processing") return "⏳ " + escapeHtml(r.storeName || "店铺") + " 创建中";
          return "❌ " + escapeHtml(r.storeName || "店铺") + ": " + escapeHtml(r.msg || "失败");
        }).join("<br>");
      } else { statusEl.innerHTML = "✅ 上货成功"; }
      return;
    }
    if (data && data.code === 202) { statusEl.innerHTML = "⏳ 商品创建中，请稍后查看"; return; }
    statusEl.innerHTML = '<span style="color:#ff4d4f;">❌ ' + escapeHtml((data && data.msg) || "失败") + '</span>';
  }

  // ===== 初始化 =====
  chrome.storage.local.get(["erp_token", "erp_user"], function(res) {
    if (res.erp_token && res.erp_user) {
      showMainPage(res.erp_user);
    } else {
      showLoginPage();
    }
    miniBtn.style.display = "flex";
  });

  // ✅ 注入网页桥接
  injectWebPageBridge();

  // URL 变化监听
  setInterval(function() {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      pendingCards.clear();
      if (cardObserver) { cardObserver.disconnect(); cardObserver = null; }
      if (isLoggedIn) {
        setTimeout(function() { scheduleInjectProductCards(1200); autoLoadCurrentItem(); }, 1200);
      }
    }
  }, 1000);

  // DOM 变化监听
  var domObserver = new MutationObserver(function(mutations) {
    if (!isLoggedIn) return;
    if (!isOzonListPage()) return;
    var hasNew = mutations.some(function(m) {
      return Array.from(m.addedNodes || []).some(function(n) {
        return n.nodeType === 1 && ((n.matches && n.matches(".tile-root")) || (n.querySelector && n.querySelector(".tile-root")));
      });
    });
    if (hasNew) scheduleInjectProductCards(600);
  });
  domObserver.observe(document.body, { childList: true, subtree: true });

})();
export default {
  async fetch(request, env) {

    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "*",
      "Access-Control-Max-Age": "86400"
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: cors });
    }

    const url = new URL(request.url);
    const path = url.pathname;

    function respond(data, status) {
      return new Response(JSON.stringify(data), {
        status: status || 200,
        headers: {
          "Content-Type": "application/json;charset=UTF-8",
          ...cors
        }
      });
    }

    if (path === "/" || path === "") {
      return respond({ code: 0, msg: "Ozon ERP API", version: "4.0.0" });
    }

    if (path === "/health") {
      return respond({ code: 0, msg: "ok", time: new Date().toISOString() });
    }

    const VALID_API_KEY = env.MY_API_KEY || "zhang147..";
    const apiKey = request.headers.get("X-API-Key") || url.searchParams.get("apikey");
    if (!apiKey || apiKey !== VALID_API_KEY) {
      return respond({ code: 401, msg: "Unauthorized" }, 401);
    }

    const MENGLAR_TOKEN = env.MENGLAR_TOKEN;
    const OZON_CLIENT_ID = env.OZON_CLIENT_ID;
    const OZON_API_KEY = env.OZON_API_KEY;

    if (!MENGLAR_TOKEN || !MENGLAR_TOKEN.startsWith("Bearer ")) {
      return respond({ code: 500, msg: "MENGLAR_TOKEN 未配置" }, 500);
    }

    const menglarHeaders = {
      "Authorization": MENGLAR_TOKEN,
      "Content-Type": "application/json",
      "small-program": "plugin"
    };

    function sleep(ms) {
      return new Promise(function(resolve) { setTimeout(resolve, ms); });
    }

    function uniqueIds(ids) {
      return [...new Set((ids || []).map(function(i) {
        return String(i).trim();
      }).filter(Boolean))];
    }

    function chunkArray(arr, size) {
      const result = [];
      for (let i = 0; i < arr.length; i += size) {
        result.push(arr.slice(i, i + size));
      }
      return result;
    }

    async function safeFetch(fetchUrl, options, label) {
      try {
        const res = await fetch(fetchUrl, options);
        const text = await res.text();
        console.log(`[safeFetch] ${label} 状态码:`, res.status);
        console.log(`[safeFetch] ${label} 响应:`, text.slice(0, 300));
        let data = null;
        try {
          data = text ? JSON.parse(text) : null;
        } catch (e) {
          return {
            ok: false,
            code: res.status,
            msg: label + " JSON解析失败",
            raw: text?.slice(0, 300)
          };
        }
        if (!res.ok) {
          return {
            ok: false,
            code: res.status,
            msg: (data?.message || data?.msg || data?.error?.message || label + " 请求失败"),
            data: data
          };
        }
        return { ok: true, ...data };
      } catch (e) {
        return { ok: false, code: 500, msg: label + " 网络异常：" + e.message };
      }
    }

    async function callOzonApi(endpoint, body) {
      if (!OZON_CLIENT_ID || !OZON_API_KEY) {
        return { ok: false, code: 500, msg: "Ozon API 凭证未配置" };
      }
      return await safeFetch(
        "https://api-seller.ozon.ru" + endpoint,
        {
          method: "POST",
          headers: {
            "Client-Id": OZON_CLIENT_ID,
            "Api-Key": OZON_API_KEY,
            "Content-Type": "application/json"
          },
          body: JSON.stringify(body || {})
        },
        "ozon:" + endpoint
      );
    }

    async function queryHotItem(ids) {
      return await safeFetch(
        "https://ozon.menglar.com/api/ozon-report-service/v1/itemRanking/hotItem",
        { method: "POST", headers: menglarHeaders, body: JSON.stringify(ids.map(String)) },
        "queryHotItem"
      );
    }

    async function queryItemsCache(ids) {
      return await safeFetch(
        "https://ozon.menglar.com/api/ozon-report-service/v1/item/itemsCache",
        { method: "POST", headers: menglarHeaders, body: JSON.stringify(ids.map(Number)) },
        "queryItemsCache"
      );
    }

    async function queryDetail(skuId) {
      return await safeFetch(
        "https://ozon.menglar.com/api/ozon-report-service/v1/plugin/dimensions/profitProductInfo?skuId=" + skuId,
        { method: "GET", headers: menglarHeaders },
        "queryDetail"
      );
    }

    // ✅ 轮询获取 product_id（最多等 20 秒）
    async function getProductIdByTaskId(taskId) {
      const MAX_RETRY = 10;
      let retryInterval = 2000;

      for (let i = 0; i < MAX_RETRY; i++) {
        await sleep(retryInterval);
        const result = await callOzonApi("/v1/product/import/info", { task_id: taskId });

        if (!result.ok) {
          console.log(`[轮询] 第${i+1}次 失败，继续...`);
          continue;
        }

        const items = result?.result?.items || [];
        if (items.length > 0) {
          const item = items[0];
          const pid = item?.product_id;
          const status = item?.status;
          const errors = item?.errors || [];

          console.log(`[轮询] 第${i+1}次 - status=${status}, product_id=${pid}`);
          if (errors.length > 0) {
            console.log(`[轮询] errors:`, JSON.stringify(errors));
          }

          if (pid && pid !== 0) return { pid, errors };
          if (status === "failed") return { pid: null, errors };
        }

        if (i > 5) retryInterval = 3000;
      }

      return { pid: null, errors: [{ code: "timeout", message: "轮询超时" }] };
    }

    // ✅ 获取主图 + 副图
    async function getImagesBySkuId(skuId) {
      try {
        const result = await callOzonApi("/v2/product/info/list", {
          sku: [parseInt(skuId)]
        });
        if (!result.ok) return [];
        const item = result?.result?.items?.[0];
        if (!item) return [];
        const imgs = [];
        if (item.primary_image) imgs.push(item.primary_image);
        if (Array.isArray(item.images)) {
          item.images.forEach(function(img) {
            const imgUrl = typeof img === "string" ? img : img?.url;
            if (imgUrl && !imgs.includes(imgUrl)) imgs.push(imgUrl);
          });
        }
        console.log("[图片] 主图+副图共:", imgs.length, "张");
        return imgs.slice(0, 15);
      } catch (e) {
        return [];
      }
    }

    function mergeData(id, hotItem, cache, detail) {
      const base = hotItem || {};
      const cacheItem = cache || {};
      const detailData = detail || {};
      return {
        itemId: base.itemId || cacheItem.itemId || detailData.skuId || Number(id),
        skuName: cacheItem.skuName || base.skuName || "",
        photo: cacheItem.photo || detailData.thumbnailUrl || "",
        brand: base.brand || cacheItem.brand || "",
        catNamePath: base.catNamePath || cacheItem.catNamePath || "",
        avgPrice: base.avgPrice ?? null,
        avgPriceRmb: base.avgPriceRmb ?? null,
        price: detailData.price ?? null,
        priceRmb: detailData.priceRmb ?? null,
        monthSales: base.monthSales ?? cacheItem.monthSales ?? null,
        monthGmv: base.monthGmv ?? cacheItem.monthGmv ?? null,
        monthGmvRmb: base.monthGmvRmb ?? cacheItem.monthGmvRmb ?? null,
        monthSalesRatio: base.monthSalesRatio ?? cacheItem.monthSalesRatio ?? null,
        dayAvgSales: base.dayAvgSales ?? null,
        dayAvgGmv: base.dayAvgGmv ?? null,
        sessionCount: base.sessionCount ?? cacheItem.sessionCount ?? null,
        monthShow: base.monthShow ?? cacheItem.monthShow ?? null,
        clickRatio: base.clickRatio ?? cacheItem.clickRatio ?? null,
        convToCartPdp: base.convToCartPdp ?? cacheItem.convToCartPdp ?? null,
        searchCartRatio: base.searchCartRatio ?? null,
        gpm: base.gpm ?? detailData.gpm ?? null,
        drr: base.drr ?? null,
        adsales: base.adsales ?? null,
        redemptionrate: base.redemptionrate ?? null,
        redemptionsales: base.redemptionsales ?? null,
        weight: detailData.weight ?? base.weight ?? null,
        volume: base.volume ?? cacheItem.volume ?? null,
        dimensionsLength: detailData.productLength ?? base.dimensionsLength ?? null,
        dimensionsWidth: detailData.productWidth ?? base.dimensionsWidth ?? null,
        dimensionsHeight: detailData.productHeight ?? base.dimensionsHeight ?? null,
        fboCommissionRate: detailData.fboCommissionRate ?? null,
        fbsCommissionRate: detailData.fbsCommissionRate ?? null,
        sources: base.sources ?? cacheItem.sources ?? null,
        sendDay: base.sendDay ?? null,
        createDt: base.createDt ?? cacheItem.createDt ?? null,
        logDate: base.logDate ?? null
      };
    }

    function hasValidMergedData(item) {
      if (!item) return false;
      const fields = [
        item.skuName, item.catNamePath, item.photo, item.brand,
        item.monthSales, item.monthGmvRmb, item.avgPriceRmb,
        item.sessionCount, item.weight, item.dimensionsLength, item.logDate
      ];
      for (let i = 0; i < fields.length; i++) {
        if (fields[i] !== null && fields[i] !== undefined && fields[i] !== "") return true;
      }
      return false;
    }

    // ===== GET /debug/follow-sell/:sku =====
    const debugRoute = path.match(/^\/debug\/follow-sell\/(\d+)$/);
    if (debugRoute && request.method === "GET") {
      const sku = debugRoute[1];
      const report = {
        sku,
        env_check: {
          has_client_id: !!OZON_CLIENT_ID,
          client_id_prefix: OZON_CLIENT_ID ? OZON_CLIENT_ID.substring(0, 4) + "****" : "未配置",
          has_api_key: !!OZON_API_KEY,
          api_key_prefix: OZON_API_KEY ? OZON_API_KEY.substring(0, 4) + "****" : "未配置"
        },
        steps: []
      };

      const authTest = await callOzonApi("/v2/product/info/list", { sku: [parseInt(sku)] });
      report.steps.push({
        step: "1_ozon_auth",
        ok: authTest.ok,
        msg: authTest.msg,
        data: authTest.ok ? { found: (authTest.result?.items || []).length > 0 } : null
      });

      if (!authTest.ok) {
        report.conclusion = "❌ STEP 1 失败：Ozon API 凭证无效 - " + authTest.msg;
        return respond({ code: 500, ...report });
      }

      const timestamp = Date.now().toString(36).toUpperCase();
      const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
      let randomPart = "";
      for (let i = 0; i < 8; i++) {
        randomPart += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      const offerId = "JZ" + timestamp + randomPart;

      const importResult = await callOzonApi("/v1/product/import-by-sku", {
        items: [{
          sku: parseInt(sku),
          name: "Test_" + sku,
          offer_id: offerId,
          currency_code: "RUB",
          price: "999",
          old_price: "999",
          vat: "0"
        }]
      });

      report.steps.push({
        step: "2_import_by_sku",
        ok: importResult.ok,
        msg: importResult.msg,
        result: importResult.result || null
      });

      if (!importResult.ok) {
        report.conclusion = "❌ STEP 2 失败：" + importResult.msg;
        return respond({ code: 500, ...report });
      }

      const taskId = importResult.result?.task_id;
      const unmatched = importResult.result?.unmatched_sku_list || [];

      report.steps.push({
        step: "2b_task_info",
        task_id: taskId,
        unmatched_sku_list: unmatched
      });

      if (unmatched.length > 0) {
        report.conclusion = "❌ SKU 不存在: " + unmatched.join(", ");
        return respond({ code: 400, ...report });
      }

      const pollResults = [];
      for (let i = 0; i < 5; i++) {
        await sleep(3000);
        const pollResult = await callOzonApi("/v1/product/import/info", { task_id: taskId });
        const items = pollResult?.result?.items || [];
        pollResults.push({
          attempt: i + 1,
          status: items[0]?.status || "unknown",
          product_id: items[0]?.product_id || 0,
          errors: items[0]?.errors || []
        });
        if (items[0]?.status === "imported" || items[0]?.status === "failed") break;
      }

      report.steps.push({ step: "3_poll_results", task_id: taskId, polls: pollResults });

      const lastPoll = pollResults[pollResults.length - 1];
      if (lastPoll.product_id && lastPoll.product_id !== 0) {
        report.conclusion = "✅ 全部正常！product_id=" + lastPoll.product_id;
        return respond({ code: 0, ...report });
      } else {
        report.conclusion = "⏳ 状态: " + lastPoll.status + " errors: " + JSON.stringify(lastPoll.errors);
        return respond({ code: 503, ...report });
      }
    }

    // ===== GET /item/:id =====
    const singleRoute = path.match(/^\/item\/(\d+)$/);
    if (singleRoute && request.method === "GET") {
      try {
        const result = await queryHotItem([singleRoute[1]]);
        if (!result.ok) return respond({ code: result.code || 500, msg: result.msg, data: null }, 500);
        return respond({ code: 0, msg: "success", data: result.data?.[0] || null });
      } catch (e) {
        return respond({ code: 500, msg: e.message, data: null }, 500);
      }
    }

    // ===== GET /detail/:id =====
    const detailRoute = path.match(/^\/detail\/(\d+)$/);
    if (detailRoute && request.method === "GET") {
      try {
        const result = await queryDetail(detailRoute[1]);
        if (!result.ok) return respond({ code: result.code || 500, msg: result.msg, data: null }, 500);
        return respond({ code: 0, msg: "success", data: result.data || null });
      } catch (e) {
        return respond({ code: 500, msg: e.message, data: null }, 500);
      }
    }

    // ===== GET /full/:id =====
    const full = path.match(/^\/full\/(\d+)$/);
    if (full && request.method === "GET") {
      try {
        const id = full[1];
        const [hotResult, cacheResult, detailResult] = await Promise.allSettled([
          queryHotItem([id]),
          queryItemsCache([id]),
          queryDetail(id)
        ]);
        const hotItem = hotResult.status === "fulfilled" && hotResult.value?.ok
          ? hotResult.value.data?.[0] || null : null;
        const cacheList = cacheResult.status === "fulfilled" && cacheResult.value?.ok
          && Array.isArray(cacheResult.value?.data) ? cacheResult.value.data : [];
        const cacheWrap = cacheList.find(function(i) {
          return String(i?.sku_id) === String(id)
            || String(i?.itemId) === String(id)
            || String(i?.items?.[0]?.itemId) === String(id);
        });
        const cacheData = cacheWrap?.items?.[0] || null;
        const detailData = detailResult.status === "fulfilled" && detailResult.value?.ok
          ? detailResult.value.data || null : null;
        const merged = mergeData(id, hotItem, cacheData, detailData);
        if (!hasValidMergedData(merged)) {
          return respond({
            code: 404,
            msg: "商品未收录或暂无有效数据",
            sources: { hotItem: !!hotItem, cache: !!cacheData, detail: !!detailData },
            data: null
          }, 404);
        }
        return respond({
          code: 0, msg: "success",
          sources: { hotItem: !!hotItem, cache: !!cacheData, detail: !!detailData },
          data: merged
        });
      } catch (e) {
        return respond({ code: 500, msg: e.message, data: null }, 500);
      }
    }

    // ===== POST /items =====
    if (path === "/items" && request.method === "POST") {
      try {
        const body = await request.json();
        const ids = uniqueIds(body.ids);
        if (!ids.length) return respond({ code: 400, msg: "ids 不能为空", data: null }, 400);
        const groups = chunkArray(ids, 50);
        const finalItems = [];
        for (const group of groups) {
          const result = await queryHotItem(group);
          if (result?.ok && Array.isArray(result.data)) finalItems.push(...result.data);
        }
        return respond({ code: 0, msg: "success", total: finalItems.length, data: finalItems });
      } catch (e) {
        return respond({ code: 500, msg: e.message, data: null }, 500);
      }
    }

    // ===== POST /full/batch =====
    if (path === "/full/batch" && request.method === "POST") {
      try {
        const body = await request.json();
        const ids = uniqueIds(body.ids);
        if (!ids.length) return respond({ code: 400, msg: "ids 不能为空", data: null }, 400);
        const groups = chunkArray(ids, 20);
        const mergedAll = [];
        for (const group of groups) {
          const [hotResult, cacheResult] = await Promise.allSettled([
            queryHotItem(group),
            queryItemsCache(group)
          ]);
          const hotItems = hotResult.status === "fulfilled" && hotResult.value?.ok
            && Array.isArray(hotResult.value.data) ? hotResult.value.data : [];
          const cacheItems = cacheResult.status === "fulfilled" && cacheResult.value?.ok
            && Array.isArray(cacheResult.value.data) ? cacheResult.value.data : [];
          for (const id of group) {
            const hot = hotItems.find(function(i) { return String(i.itemId) === String(id); });
            const cacheWrap = cacheItems.find(function(i) {
              return String(i.sku_id) === String(id) || String(i.itemId) === String(id);
            });
            const cacheItem = cacheWrap?.items?.[0] || null;
            mergedAll.push(mergeData(id, hot, cacheItem, null));
          }
        }
        return respond({ code: 0, msg: "success", total: mergedAll.length, data: mergedAll });
      } catch (e) {
        return respond({ code: 500, msg: e.message, data: null }, 500);
      }
    }

    // ===== GET /warehouses =====
    if (path === "/warehouses" && request.method === "GET") {
      try {
        const result = await callOzonApi("/v1/warehouse/list", {});
        const warehouses = result?.result || [];
        if (!Array.isArray(warehouses)) {
          return respond({ code: 500, msg: "获取仓库列表失败" }, 500);
        }
        return respond({
          code: 0, msg: "success", total: warehouses.length,
          data: warehouses.map(function(w) {
            return { warehouse_id: w.warehouse_id, name: w.name };
          })
        });
      } catch (e) {
        return respond({ code: 500, msg: e.message }, 500);
      }
    }

    // ===== POST /follow-sell/add-offer =====
    if (path === "/follow-sell/add-offer" && request.method === "POST") {
      try {
        const body = await request.json();
        let { sku, price, name, quantity, warehouse_id, images } = body;

        if (sku) {
          sku = String(sku).trim();
          const match = sku.match(/(\d+)/);
          if (match) sku = match[1];
        }

        if (!sku || !price) {
          return respond({ code: 400, msg: "缺少必填参数：sku、price" }, 400);
        }

        if (!OZON_CLIENT_ID || !OZON_API_KEY) {
          return respond({ code: 500, msg: "Ozon API 凭证未配置" }, 500);
        }

        console.log("[跟卖] 开始 SKU:", sku, "price:", price);

        // ✅ 获取图片
        let uploadImages = [];
        if (images && images.length > 0) {
          uploadImages = images.filter(u => u && String(u).startsWith("http")).slice(0, 15);
        }
        if (uploadImages.length === 0) {
          uploadImages = await getImagesBySkuId(sku);
        }
        console.log("[跟卖] 图片数量:", uploadImages.length);

        // ✅ 生成唯一 offer_id（时间戳 + 随机，确保不冲突）
        const timestamp = Date.now().toString(36).toUpperCase();
        const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        let randomPart = "";
        for (let i = 0; i < 8; i++) {
          randomPart += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        const myOfferId = "JZ" + timestamp + randomPart;
        console.log("[跟卖] offer_id:", myOfferId);

        // ✅ 创建跟卖商品
        const importResult = await callOzonApi("/v1/product/import-by-sku", {
          items: [{
            sku: parseInt(sku),
            offer_id: myOfferId,
            name: name || ("Product_" + sku),
            currency_code: "RUB",
            price: String(price),
            old_price: String(price),
            vat: "0"
          }]
        });

        console.log("[跟卖] import-by-sku 返回:", JSON.stringify(importResult).slice(0, 300));

        if (!importResult.ok) {
          return respond({
            code: importResult.code || 500,
            msg: "创建商品失败: " + importResult.msg,
            details: importResult.data
          }, 500);
        }

        const unmatched = importResult.result?.unmatched_sku_list || [];
        if (unmatched.length > 0) {
          return respond({ code: 400, msg: "SKU 不存在: " + unmatched.join(", ") }, 400);
        }

        const taskId = importResult.result?.task_id;
        if (!taskId) {
          return respond({ code: 500, msg: "未获取到 task_id" }, 500);
        }

        console.log("[跟卖] task_id:", taskId);

        // ✅ 轮询获取 product_id（最多等 20 秒）
        const pollResult = await getProductIdByTaskId(taskId);
        const productId = pollResult.pid;
        const pollErrors = pollResult.errors || [];

        // ✅ 如果有错误，返回详细错误信息
        if (!productId && pollErrors.length > 0) {
          const firstError = pollErrors[0];
          // 不是超时错误，是真实的业务错误
          if (firstError.code !== "timeout") {
            return respond({
              code: 400,
              msg: "商品创建失败: " + (firstError.description || firstError.message || firstError.code),
              errors: pollErrors
            }, 400);
          }
        }

        if (!productId) {
          // 超时，返回 202 让前端继续轮询
          return respond({
            code: 202,
            msg: "商品创建中，请稍后查询状态",
            data: {
              task_id: taskId,
              offer_id: myOfferId,
              sku: sku,
              images: uploadImages,
              status: "processing"
            }
          }, 202);
        }

        console.log("[跟卖] product_id:", productId);

        // ✅ 上传图片
        let imageUploaded = false;
        let uploadedCount = 0;
        let imageError = null;

        if (uploadImages.length > 0) {
          await sleep(2000);
          console.log("[图片] 上传", uploadImages.length, "张");

          const imgResult = await callOzonApi("/v1/product/pictures/import", {
            product_id: parseInt(productId),
            images: uploadImages
          });

          console.log("[图片] 上传结果:", imgResult.ok);

          if (imgResult.ok && imgResult.result?.pictures) {
            imageUploaded = true;
            uploadedCount = (imgResult.result.pictures || []).filter(
              p => p.state === "uploaded" || p.state === "exists"
            ).length;
          } else {
            imageError = imgResult.msg;
          }
        }

        // ✅ 设置库存
        let stockSet = false;
        let stockError = null;
        if (quantity && warehouse_id) {
          const stockResult = await callOzonApi("/v2/products/stocks", {
            stocks: [{
              product_id: parseInt(productId),
              stock: parseInt(quantity),
              warehouse_id: parseInt(warehouse_id)
            }]
          });
          stockSet = stockResult.ok;
          if (!stockSet) stockError = stockResult.msg;
        }

        return respond({
          code: 0,
          msg: "跟卖成功",
          data: {
            product_id: productId,
            offer_id: myOfferId,
            sku: sku,
            price: price,
            imageCount: uploadImages.length,
            imageUploaded,
            uploadedCount,
            imageError: imageError || undefined,
            stockSet,
            stockError: stockError || undefined
          }
        });

      } catch (e) {
        console.error("[跟卖] 异常:", e.message);
        return respond({ code: 500, msg: "服务器错误: " + e.message }, 500);
      }
    }

    // ===== POST /follow-sell/check-task =====
    if (path === "/follow-sell/check-task" && request.method === "POST") {
      try {
        const body = await request.json();
        const { task_id, product_id, images } = body;

        if (!task_id && !product_id) {
          return respond({ code: 400, msg: "缺少 task_id 或 product_id" }, 400);
        }

        let finalProductId = product_id;

        if (!finalProductId && task_id) {
          const pollResult = await callOzonApi("/v1/product/import/info", { task_id });
          const items = pollResult?.result?.items || [];

          console.log("[check-task] 查询结果:", JSON.stringify(items[0]).slice(0, 300));

          if (items[0]?.product_id && items[0].product_id !== 0) {
            finalProductId = items[0].product_id;
          } else if (items[0]?.status === "failed") {
            const errors = items[0]?.errors || [];
            const firstError = errors[0];
            return respond({
              code: 400,
              msg: "商品创建失败: " + (firstError?.description || firstError?.message || firstError?.code || "未知错误"),
              errors: errors
            }, 400);
          }
        }

        if (!finalProductId) {
          return respond({
            code: 202,
            msg: "商品仍在处理中，请稍后再试",
            data: { task_id, status: "processing" }
          });
        }

        // ✅ 有 product_id，上传图片
        let imageUploaded = false;
        let uploadedCount = 0;

        if (images && images.length > 0) {
          await sleep(2000);
          const uploadImgs = images.filter(u => u && String(u).startsWith("http")).slice(0, 15);

          const imgResult = await callOzonApi("/v1/product/pictures/import", {
            product_id: parseInt(finalProductId),
            images: uploadImgs
          });

          if (imgResult.ok && imgResult.result?.pictures) {
            imageUploaded = true;
            uploadedCount = (imgResult.result.pictures || []).filter(
              p => p.state === "uploaded" || p.state === "exists"
            ).length;
          }
        }

        return respond({
          code: 0,
          msg: "任务完成",
          data: {
            product_id: finalProductId,
            task_id,
            imageUploaded,
            uploadedCount
          }
        });
      } catch (e) {
        return respond({ code: 500, msg: e.message }, 500);
      }
    }

    return respond({ code: 404, msg: "接口不存在" }, 404);
  }
};